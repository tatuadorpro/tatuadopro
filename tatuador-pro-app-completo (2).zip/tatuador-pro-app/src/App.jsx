import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './App.css'

// Componentes
import Login from './components/Login'
import Dashboard from './components/Dashboard'
import Sidebar from './components/Sidebar'
import BottomNavigation from './components/BottomNavigation'

// Páginas
import Ganhos from './components/pages/Ganhos'
import Gastos from './components/pages/Gastos'
import Clientes from './components/pages/Clientes'
import Agenda from './components/pages/Agenda'
import Loja from './components/pages/Loja'
import LojaPublica from './components/pages/LojaPublica'
import PortfolioPublico from './components/pages/PortfolioPublico'
import Portfolio from './components/pages/Portfolio'
import Estoque from './components/pages/Estoque'
import Calculadora from './components/pages/Calculadora'
import Relatorios from './components/pages/Relatorios'
import PrivacyPolicy from './components/pages/PrivacyPolicy'
import TermsOfService from './components/pages/TermsOfService'
import AboutUs from './components/pages/AboutUs'

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768)

  // Dados da loja (simulando dados compartilhados)
  const [configLoja] = useState({
    nome: 'ART TATTOO STORE',
    whatsapp: '+5553999621044',
    instagram: 'alex_souza_tattoo',
    descricao: 'Loja oficial do estúdio ART TATTOO. Tatuagens, piercings, cursos e produtos de qualidade.',
    ativa: true
  })

  const [produtos] = useState([
    {
      id: 1,
      tipo: 'tatuagem',
      nome: 'Tatuagem Pequena (5-10cm)',
      categoria: 'Tatuagens',
      preco: 150.00,
      precoPromocional: null,
      estoque: 0,
      imagemUrl: '',
      descricao: 'Tatuagem personalizada de 5 a 10 centímetros',
      disponivel: true
    },
    {
      id: 2,
      tipo: 'curso',
      nome: 'Curso Básico de Tatuagem',
      categoria: 'Cursos',
      preco: 800.00,
      precoPromocional: 650.00,
      estoque: 5,
      imagemUrl: '',
      descricao: 'Curso completo para iniciantes na arte da tatuagem',
      disponivel: true
    },
    {
      id: 3,
      tipo: 'produto',
      nome: 'Kit de Cuidados Pós-Tatuagem',
      categoria: 'Produtos',
      preco: 45.00,
      precoPromocional: null,
      estoque: 20,
      imagemUrl: '',
      descricao: 'Kit completo para cuidados após a tatuagem',
      disponivel: true
    }
  ])

  // Detectar mudanças no tamanho da tela
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768)
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  // Layout principal do aplicativo
  return (
    <Router>
      <div className="min-h-screen bg-background text-foreground">
        <Routes>
          {/* Rota pública da loja */}
          <Route path="/loja-publica" element={<LojaPublica configLoja={configLoja} produtos={produtos} />} />
          
          {/* Rota pública do portfólio */}
          <Route path="/portfolio-publico/:portfolioId" element={<PortfolioPublico />} />
          {!isMobile && <Route path="/politica-de-privacidade" element={<PrivacyPolicy />} />}
          {!isMobile && <Route path="/termos-de-uso" element={<TermsOfService />} />}
          {!isMobile && <Route path="/sobre-nos" element={<AboutUs />} />}
          
          {/* Rotas autenticadas */}
          <Route path="/*" element={
            isAuthenticated ? (
              <>
                {/* Layout Desktop - Sidebar */}
                {!isMobile && (
                  <div className="flex">
                    <Sidebar />
                    <main className="flex-1 ml-64">
                      <div className="p-6">
                        <Routes>
                          <Route path="/" element={<Dashboard />} />
                          <Route path="/dashboard" element={<Dashboard />} />
                          <Route path="/ganhos" element={<Ganhos />} />
                          <Route path="/gastos" element={<Gastos />} />
                          <Route path="/clientes" element={<Clientes />} />
                          <Route path="/agenda" element={<Agenda />} />
                          <Route path="/loja" element={<Loja />} />
                          <Route path="/portfolio" element={<Portfolio />} />
                          <Route path="/estoque" element={<Estoque />} />
                          <Route path="/calculadora" element={<Calculadora />} />
                          <Route path="/relatorios" element={<Relatorios />} />

                        </Routes>
                      </div>
                    </main>
                  </div>
                )}

                {/* Layout Mobile - Bottom Navigation */}
                {isMobile && (
                  <div className="flex flex-col min-h-screen">
                    <main className="flex-1 pb-20">
                      <div className="p-4">
                        <Routes>
                          <Route path="/" element={<Dashboard />} />
                          <Route path="/dashboard" element={<Dashboard />} />
                          <Route path="/ganhos" element={<Ganhos />} />
                          <Route path="/gastos" element={<Gastos />} />
                          <Route path="/clientes" element={<Clientes />} />
                          <Route path="/agenda" element={<Agenda />} />
                          <Route path="/loja" element={<Loja />} />
                          <Route path="/portfolio" element={<Portfolio />} />
                          <Route path="/estoque" element={<Estoque />} />
                          <Route path="/calculadora" element={<Calculadora />} />
                          <Route path="/relatorios" element={<Relatorios />} />
                        </Routes>
                      </div>
                    </main>
                    <BottomNavigation />
                  </div>
                )}
              </>
            ) : (
              <Login onLogin={() => setIsAuthenticated(true)} />
            )
          } />
        </Routes>
      </div>
    </Router>
  )
}

export default App

