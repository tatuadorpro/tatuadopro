import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { 
  Calculator, 
  Settings, 
  DollarSign,
  Clock,
  Save,
  Share,
  Zap,
  Plus,
  Trash2,
  Edit,
  Table
} from 'lucide-react'

const Calculadora = () => {
  // Configurações da calculadora
  const [config, setConfig] = useState({
    whatsappNumber: '+5553999621044',
    studioName: 'ART TATTOO',
    instagramHandle: 'alex_souza_tattoo',
    hourlyRate: 120,
    enableFlashTattoos: true
  })

  // Preços de tatuagens por local e tamanho (dados da calculadora original)
  const [precosTatuagem, setPrecosTatuagem] = useState({
    antebraco: { '5-10': 100, '11-15': 250, '16-20': 500, '21-30': 750 },
    braco_superior: { '5-10': 100, '11-15': 250, '16-20': 500, '21-30': 750, '31-40': 850 },
    fechamento_braco: { '31-40': 2000, '41-50': 2500, '>50': 3000 },
    mao: { '5-10': 300, '11-15': 400, '16-20': 500 },
    antebraco_mao: { '21-30': 750, '31-40': 850 },
    costas: { '21-30': 2750, '31-40': 3500, '>50': 3500 },
    peitoral: { '5-10': 300, '11-15': 600, '16-20': 750, '21-30': 1000, '31-40': 1300 },
    peito_lateral: { '5-10': 250, '11-15': 500, '16-20': 650 },
    abdomen: { '5-10': 150, '11-15': 250, '16-20': 300, '21-30': 500, '31-40': 600 },
    coxa: { '5-10': 200, '11-15': 300, '16-20': 500, '21-30': 750, '31-40': 850 },
    canela: { '5-10': 200, '11-15': 300, '16-20': 500, '21-30': 750, '31-40': 800 },
    panturrilha: { '5-10': 200, '11-15': 300, '16-20': 500, '21-30': 750, '31-40': 800 },
    corpo: { '5-10': 200, '11-15': 300, '16-20': 500, '21-30': 750, '31-40': 800 },
    pescoco_frente: { '5-10': 300, '11-15': 500, '16-20': 600 },
    pescoco_lateral: { '5-10': 200, '11-15': 400, '16-20': 500, '21-30': 700 },
    pescoco_nuca: { '5-10': 200, '11-15': 300, '16-20': 450, '21-30': 550 }
  })

  // Preços de flash tattoos (dados da calculadora original)
  const [precosFlash, setPrecosFlash] = useState({
    1: 100, 2: 160, 3: 200, 4: 240, 5: 275,
    6: 325, 7: 375, 8: 425, 9: 475, 10: 525
  })

  // Estados da calculadora principal
  const [calculoTatuagem, setCalculoTatuagem] = useState({
    nome: '',
    observacoes: '',
    local: '',
    tamanho: '',
    resultado: null
  })

  // Estados da calculadora flash
  const [calculoFlash, setCalculoFlash] = useState({
    nome: '',
    observacoes: '',
    quantidade: 1,
    resultado: null
  })

  // Estados para edição de preços
  const [editandoPrecos, setEditandoPrecos] = useState(false)
  const [novoLocal, setNovoLocal] = useState('')

  const [activeTab, setActiveTab] = useState('calculadora')

  // Locais do corpo formatados
  const locaisCorpo = {
    antebraco: 'Antebraço',
    braco_superior: 'Braço Superior',
    fechamento_braco: 'Fechamento Braço',
    mao: 'Mão',
    antebraco_mao: 'Antebraço + Mão',
    costas: 'Costas',
    peitoral: 'Peitoral',
    peito_lateral: 'Peito Lateral',
    abdomen: 'Abdômen',
    coxa: 'Coxa',
    canela: 'Canela',
    panturrilha: 'Panturrilha',
    corpo: 'Corpo',
    pescoco_frente: 'Pescoço Frente',
    pescoco_lateral: 'Pescoço Lateral',
    pescoco_nuca: 'Pescoço Nuca'
  }

  // Faixas de tamanho disponíveis
  const faixasTamanho = ['5-10', '11-15', '16-20', '21-30', '31-40', '41-50', '>50']

  // Calcular valor da tatuagem
  const calcularTatuagem = () => {
    if (!calculoTatuagem.local || !calculoTatuagem.tamanho || !calculoTatuagem.nome) {
      alert('Preencha todos os campos obrigatórios')
      return
    }

    const preco = precosTatuagem[calculoTatuagem.local]?.[calculoTatuagem.tamanho]
    if (!preco) {
      alert('Preço não encontrado para esta combinação')
      return
    }

    const tempoEstimado = Math.ceil(preco / config.hourlyRate)
    const tempoTexto = tempoEstimado === 1 ? '1 hora' : `${tempoEstimado} horas`

    setCalculoTatuagem({
      ...calculoTatuagem,
      resultado: {
        preco,
        tempoEstimado: tempoTexto,
        localFormatado: locaisCorpo[calculoTatuagem.local]
      }
    })
  }

  // Calcular valor flash tattoos
  const calcularFlash = () => {
    if (!calculoFlash.nome || !calculoFlash.quantidade) {
      alert('Preencha todos os campos obrigatórios')
      return
    }

    let preco = precosFlash[calculoFlash.quantidade]
    if (!preco) {
      // Calcular baseado na quantidade mais próxima (lógica da calculadora original)
      const quantities = Object.keys(precosFlash).map(Number).sort((a, b) => a - b)
      let baseQuantity = quantities[0]
      let basePrice = precosFlash[baseQuantity]
      
      for (let q of quantities) {
        if (q <= calculoFlash.quantidade) {
          baseQuantity = q
          basePrice = precosFlash[q]
        }
      }
      
      const pricePerUnit = basePrice / baseQuantity
      preco = Math.round(pricePerUnit * calculoFlash.quantidade)
    }

    const tempoEstimado = Math.ceil(preco / config.hourlyRate)
    const tempoTexto = tempoEstimado === 1 ? '1 hora' : `${tempoEstimado} horas`

    setCalculoFlash({
      ...calculoFlash,
      resultado: {
        preco,
        tempoEstimado: tempoTexto
      }
    })
  }



  // Adicionar novo preço flash
  const adicionarPrecoFlash = () => {
    const novaQuantidade = Math.max(...Object.keys(precosFlash).map(Number)) + 1
    setPrecosFlash({
      ...precosFlash,
      [novaQuantidade]: 0
    })
  }

  // Remover preço flash
  const removerPrecoFlash = (quantidade) => {
    const novosPrecos = { ...precosFlash }
    delete novosPrecos[quantidade]
    setPrecosFlash(novosPrecos)
  }

  // Atualizar preço flash
  const atualizarPrecoFlash = (quantidade, novoPreco) => {
    setPrecosFlash({
      ...precosFlash,
      [quantidade]: parseFloat(novoPreco) || 0
    })
  }

  // Atualizar preço de tatuagem
  const atualizarPrecoTatuagem = (local, tamanho, novoPreco) => {
    setPrecosTatuagem({
      ...precosTatuagem,
      [local]: {
        ...precosTatuagem[local],
        [tamanho]: parseFloat(novoPreco) || 0
      }
    })
  }

  // Adicionar novo local
  const adicionarNovoLocal = () => {
    if (!novoLocal.trim()) return
    
    const chaveLocal = novoLocal.toLowerCase().replace(/\s+/g, '_')
    const novoLocalFormatado = novoLocal.trim()
    
    // Adicionar ao objeto de locais
    locaisCorpo[chaveLocal] = novoLocalFormatado
    
    // Adicionar preços iniciais vazios
    setPrecosTatuagem({
      ...precosTatuagem,
      [chaveLocal]: {}
    })
    
    setNovoLocal('')
  }

  // Remover local
  const removerLocal = (local) => {
    const novosPrecos = { ...precosTatuagem }
    delete novosPrecos[local]
    setPrecosTatuagem(novosPrecos)
    
    const novosLocais = { ...locaisCorpo }
    delete novosLocais[local]
    // Note: não podemos modificar locaisCorpo diretamente pois é uma constante
  }

  // Salvar configurações
  const salvarConfiguracoes = () => {
    // Aqui você pode implementar a lógica para salvar no localStorage ou backend
    localStorage.setItem('calculadora_config', JSON.stringify({
      config,
      precosTatuagem,
      precosFlash
    }))
    alert('Configurações salvas com sucesso!')
  }

  // Carregar configurações salvas
  useEffect(() => {
    const configSalva = localStorage.getItem('calculadora_config')
    if (configSalva) {
      try {
        const { config: configCarregada, precosTatuagem: precosCarregados, precosFlash: precosFlashCarregados } = JSON.parse(configSalva)
        setConfig(configCarregada)
        setPrecosTatuagem(precosCarregados)
        setPrecosFlash(precosFlashCarregados)
      } catch (error) {
        console.error('Erro ao carregar configurações:', error)
      }
    }
  }, [])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Calculadora de Tatuagem</h1>
          <p className="text-muted-foreground">Configure e use sua calculadora personalizada</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="calculadora">Calculadora</TabsTrigger>
          <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
        </TabsList>

        {/* Tab Calculadora */}
        <TabsContent value="calculadora" className="space-y-6">
          {/* Calculadora Principal */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calculator className="h-5 w-5" />
                <span>Calculadora de Tatuagem - {config.studioName}</span>
              </CardTitle>
              <CardDescription>
                Calcule o valor de tatuagens personalizadas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome-tatuagem">Nome do Cliente</Label>
                  <Input
                    id="nome-tatuagem"
                    value={calculoTatuagem.nome}
                    onChange={(e) => setCalculoTatuagem({...calculoTatuagem, nome: e.target.value})}
                    placeholder="Digite o nome completo"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="local-tatuagem">Local do Corpo</Label>
                  <Select 
                    value={calculoTatuagem.local} 
                    onValueChange={(value) => setCalculoTatuagem({...calculoTatuagem, local: value, tamanho: ''})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o local" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(locaisCorpo).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tamanho-tatuagem">Tamanho (cm)</Label>
                  <Select 
                    value={calculoTatuagem.tamanho} 
                    onValueChange={(value) => setCalculoTatuagem({...calculoTatuagem, tamanho: value})}
                    disabled={!calculoTatuagem.local}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Primeiro selecione o local" />
                    </SelectTrigger>
                    <SelectContent>
                      {calculoTatuagem.local && Object.keys(precosTatuagem[calculoTatuagem.local] || {}).map(tamanho => (
                        <SelectItem key={tamanho} value={tamanho}>
                          {tamanho} cm
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacoes-tatuagem">Observações/Ideias (opcional)</Label>
                <Textarea
                  id="observacoes-tatuagem"
                  value={calculoTatuagem.observacoes}
                  onChange={(e) => setCalculoTatuagem({...calculoTatuagem, observacoes: e.target.value})}
                  placeholder="Descreva a ideia para a tatuagem, estilo desejado, cores, etc..."
                />
              </div>
              
              <Button onClick={calcularTatuagem} className="w-full">
                <Calculator className="h-4 w-4 mr-2" />
                Calcular Valor
              </Button>
              
              {calculoTatuagem.resultado && (
                <Card className="bg-muted">
                  <CardContent className="pt-6">
                    <div className="text-center space-y-4">
                      <h3 className="text-lg font-semibold">Orçamento para {calculoTatuagem.nome}</h3>
                      <div className="text-3xl font-bold text-gain">
                        R$ {calculoTatuagem.resultado.preco.toLocaleString('pt-BR')}
                      </div>
                      <div className="flex items-center justify-center space-x-2 text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>Tempo estimado: {calculoTatuagem.resultado.tempoEstimado}</span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <p><strong>Local:</strong> {calculoTatuagem.resultado.localFormatado}</p>
                        <p><strong>Tamanho:</strong> {calculoTatuagem.tamanho} cm</p>
                        <p><strong>Taxa Horária:</strong> R$ {config.hourlyRate.toLocaleString('pt-BR')}</p>
                      </div>

                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>

          {/* Calculadora Flash */}
          {config.enableFlashTattoos && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="h-5 w-5" />
                  <span>Flash Tattoos (1 a 7 cm)</span>
                </CardTitle>
                <CardDescription>
                  Calcule o valor de flash tattoos em quantidade
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome-flash">Nome do Cliente</Label>
                    <Input
                      id="nome-flash"
                      value={calculoFlash.nome}
                      onChange={(e) => setCalculoFlash({...calculoFlash, nome: e.target.value})}
                      placeholder="Digite o nome completo"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="quantidade-flash">Quantidade de Flash Tattoos</Label>
                    <Input
                      id="quantidade-flash"
                      type="number"
                      min="1"
                      max="30"
                      value={calculoFlash.quantidade}
                      onChange={(e) => setCalculoFlash({...calculoFlash, quantidade: parseInt(e.target.value) || 1})}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="observacoes-flash">Observações/Ideias (opcional)</Label>
                  <Textarea
                    id="observacoes-flash"
                    value={calculoFlash.observacoes}
                    onChange={(e) => setCalculoFlash({...calculoFlash, observacoes: e.target.value})}
                    placeholder="Descreva a ideia para as flash tattoos, estilo desejado, etc..."
                  />
                </div>
                
                <Button onClick={calcularFlash} className="w-full">
                  <Zap className="h-4 w-4 mr-2" />
                  Calcular Valor Flash Tattoos
                </Button>
                
                {calculoFlash.resultado && (
                  <Card className="bg-muted">
                    <CardContent className="pt-6">
                      <div className="text-center space-y-4">
                        <h3 className="text-lg font-semibold">Orçamento Flash Tattoos para {calculoFlash.nome}</h3>
                        <div className="text-3xl font-bold text-gain">
                          R$ {calculoFlash.resultado.preco.toLocaleString('pt-BR')}
                        </div>
                        <div className="flex items-center justify-center space-x-2 text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          <span>Tempo estimado: {calculoFlash.resultado.tempoEstimado}</span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <p><strong>Quantidade:</strong> {calculoFlash.quantidade} flash tattoo{calculoFlash.quantidade > 1 ? 's' : ''}</p>
                          <p><strong>Taxa Horária:</strong> R$ {config.hourlyRate.toLocaleString('pt-BR')}</p>
                        </div>

                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Tab Configurações */}
        <TabsContent value="configuracoes" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>Configurações da Calculadora</span>
              </CardTitle>
              <CardDescription>
                Personalize sua calculadora de tatuagem
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Informações Básicas */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Informações Básicas</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="whatsapp">Número WhatsApp</Label>
                    <Input
                      id="whatsapp"
                      value={config.whatsappNumber}
                      onChange={(e) => setConfig({...config, whatsappNumber: e.target.value})}
                      placeholder="+55 53 99999-9999"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="studio">Nome do Estúdio</Label>
                    <Input
                      id="studio"
                      value={config.studioName}
                      onChange={(e) => setConfig({...config, studioName: e.target.value})}
                      placeholder="Nome do seu estúdio"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="instagram">Instagram (sem @)</Label>
                    <Input
                      id="instagram"
                      value={config.instagramHandle}
                      onChange={(e) => setConfig({...config, instagramHandle: e.target.value})}
                      placeholder="seu_usuario"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="hourly-rate">Taxa Horária (R$)</Label>
                    <Input
                      id="hourly-rate"
                      type="number"
                      value={config.hourlyRate}
                      onChange={(e) => setConfig({...config, hourlyRate: parseFloat(e.target.value) || 0})}
                      placeholder="120"
                    />
                  </div>
                </div>
              </div>

              {/* Flash Tattoos */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Flash Tattoos</h3>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="enable-flash"
                      checked={config.enableFlashTattoos}
                      onCheckedChange={(checked) => setConfig({...config, enableFlashTattoos: checked})}
                    />
                    <Label htmlFor="enable-flash">Incluir calculadora de Flash Tattoos</Label>
                  </div>
                </div>
                
                {config.enableFlashTattoos && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Preços por Quantidade</Label>
                      <Button size="sm" onClick={adicionarPrecoFlash}>
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-60 overflow-y-auto">
                      {Object.entries(precosFlash)
                        .sort(([a], [b]) => parseInt(a) - parseInt(b))
                        .map(([quantidade, preco]) => (
                        <div key={quantidade} className="flex items-center space-x-2">
                          <Label className="w-20">{quantidade} flash:</Label>
                          <Input
                            type="number"
                            value={preco}
                            onChange={(e) => atualizarPrecoFlash(quantidade, e.target.value)}
                            placeholder="Preço"
                            className="flex-1"
                          />
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => removerPrecoFlash(quantidade)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Tabela de Preços de Tatuagens */}
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Table className="h-5 w-5" />
                  <h3 className="text-lg font-semibold">Tabela de Preços de Tatuagens</h3>
                </div>
                
                {/* Estatísticas da tabela */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-4">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-4 w-4 text-gain" />
                      <div>
                        <p className="text-sm text-muted-foreground">Total de Locais</p>
                        <p className="text-2xl font-bold">{Object.keys(precosTatuagem).length}</p>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center space-x-2">
                      <Calculator className="h-4 w-4 text-blue-500" />
                      <div>
                        <p className="text-sm text-muted-foreground">Preços Configurados</p>
                        <p className="text-2xl font-bold">
                          {Object.values(precosTatuagem).reduce((total, precos) => 
                            total + Object.values(precos).filter(p => p > 0).length, 0
                          )}
                        </p>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-orange-500" />
                      <div>
                        <p className="text-sm text-muted-foreground">Taxa Horária</p>
                        <p className="text-2xl font-bold">R$ {config.hourlyRate}</p>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Adicionar novo local */}
                <div className="flex items-center space-x-2">
                  <Input
                    value={novoLocal}
                    onChange={(e) => setNovoLocal(e.target.value)}
                    placeholder="Nome do novo local (ex: Ombro, Tornozelo, etc.)"
                    className="flex-1"
                  />
                  <Button onClick={adicionarNovoLocal} disabled={!novoLocal.trim()}>
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Local
                  </Button>
                </div>

                {/* Filtros e ações em massa */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-2 md:space-y-0">
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline">
                      {Object.keys(precosTatuagem).length} locais cadastrados
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => {
                        const confirmacao = confirm('Tem certeza que deseja limpar todos os preços? Esta ação não pode ser desfeita.')
                        if (confirmacao) {
                          const novosPrecos = {}
                          Object.keys(precosTatuagem).forEach(local => {
                            novosPrecos[local] = {}
                          })
                          setPrecosTatuagem(novosPrecos)
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Limpar Preços
                    </Button>
                  </div>
                </div>

                {/* Tabela de preços */}
                <div className="overflow-x-auto border rounded-lg">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted/50">
                        <th className="border-b border-border p-3 text-left font-semibold">Local do Corpo</th>
                        {faixasTamanho.map(faixa => (
                          <th key={faixa} className="border-b border-border p-3 text-center font-semibold min-w-[100px]">
                            {faixa} cm
                          </th>
                        ))}
                        <th className="border-b border-border p-3 text-center font-semibold">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(precosTatuagem).length === 0 ? (
                        <tr>
                          <td colSpan={faixasTamanho.length + 2} className="p-8 text-center text-muted-foreground">
                            Nenhum local cadastrado. Adicione um novo local acima.
                          </td>
                        </tr>
                      ) : (
                        Object.entries(precosTatuagem).map(([local, precos]) => (
                          <tr key={local} className="hover:bg-muted/30 transition-colors">
                            <td className="border-b border-border p-3 font-medium">
                              {locaisCorpo[local] || local}
                            </td>
                            {faixasTamanho.map(faixa => (
                              <td key={faixa} className="border-b border-border p-3">
                                <Input
                                  type="number"
                                  value={precos[faixa] || ''}
                                  onChange={(e) => atualizarPrecoTatuagem(local, faixa, e.target.value)}
                                  placeholder="0"
                                  className="w-full text-center"
                                  min="0"
                                  step="10"
                                />
                              </td>
                            ))}
                            <td className="border-b border-border p-3 text-center">
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => {
                                  const confirmacao = confirm(`Tem certeza que deseja remover "${locaisCorpo[local] || local}"?`)
                                  if (confirmacao) {
                                    removerLocal(local)
                                  }
                                }}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Informações e dicas */}
                <div className="bg-muted/30 p-4 rounded-lg space-y-2">
                  <h4 className="font-semibold flex items-center">
                    <Settings className="h-4 w-4 mr-2" />
                    Dicas para Configuração
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• <strong>Deixe em branco</strong> os tamanhos que não se aplicam ao local específico</li>
                    <li>• <strong>Use valores múltiplos de 10</strong> para facilitar cálculos</li>
                    <li>• <strong>Considere a complexidade</strong> do local na hora de precificar</li>
                    <li>• <strong>Revise periodicamente</strong> seus preços conforme o mercado</li>
                    <li>• <strong>Taxa horária atual:</strong> R$ {config.hourlyRate}/hora</li>
                  </ul>
                </div>
              </div>

              {/* Botões de ação */}
              <div className="flex flex-col md:flex-row gap-3">
                <Button onClick={salvarConfiguracoes} className="flex-1">
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Todas as Configurações
                </Button>

              </div>
            </CardContent>
          </Card>
        </TabsContent>

      </Tabs>
    </div>
  )
}

export default Calculadora

