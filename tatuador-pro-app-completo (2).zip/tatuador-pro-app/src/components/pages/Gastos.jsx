import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  TrendingDown,
  DollarSign,
  Calendar,
  Filter
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const Gastos = () => {
  const [gastos, setGastos] = useState([
    {
      id: 1,
      tipoNome: 'Tintas Profissionais',
      valor: 320.00,
      dataPagamento: '2024-01-15',
      categoria: 'tintas',
      descricao: 'Kit de tintas coloridas para tatuagem'
    },
    {
      id: 2,
      tipoNome: 'Aluguel do Estúdio',
      valor: 800.00,
      dataPagamento: '2024-01-01',
      categoria: 'aluguel',
      descricao: 'Aluguel mensal do estúdio'
    },
    {
      id: 3,
      tipoNome: 'Agulhas Descartáveis',
      valor: 150.00,
      dataPagamento: '2024-01-10',
      categoria: 'agulhas',
      descricao: 'Pacote com 50 agulhas descartáveis'
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategoria, setFilterCategoria] = useState('todas')
  const [filterMes, setFilterMes] = useState('2024-01')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingGasto, setEditingGasto] = useState(null)

  const [novoGasto, setNovoGasto] = useState({
    tipoNome: '',
    valor: '',
    dataPagamento: '',
    categoria: '',
    descricao: ''
  })

  // Filtrar gastos por mês
  const gastosFiltradosPorMes = gastos.filter(gasto => 
    gasto.dataPagamento.startsWith(filterMes)
  )

  // Cálculos
  const totalGastos = gastosFiltradosPorMes.reduce((sum, gasto) => sum + gasto.valor, 0)
  const maiorGasto = Math.max(...gastosFiltradosPorMes.map(g => g.valor))
  const menorGasto = Math.min(...gastosFiltradosPorMes.map(g => g.valor))
  const mediaGastos = gastosFiltradosPorMes.length > 0 ? totalGastos / gastosFiltradosPorMes.length : 0

  // Dados para gráficos
  const gastosPorCategoria = gastosFiltradosPorMes.reduce((acc, gasto) => {
    acc[gasto.categoria] = (acc[gasto.categoria] || 0) + gasto.valor
    return acc
  }, {})

  const dadosGraficoCategoria = Object.entries(gastosPorCategoria).map(([categoria, valor]) => ({
    name: categoria.charAt(0).toUpperCase() + categoria.slice(1),
    value: valor
  }))

  // Filtros
  const gastosFiltrados = gastosFiltradosPorMes.filter(gasto => {
    const matchesSearch = gasto.tipoNome.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategoria = filterCategoria === 'todas' || gasto.categoria === filterCategoria
    return matchesSearch && matchesCategoria
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (editingGasto) {
      setGastos(gastos.map(gasto => 
        gasto.id === editingGasto.id 
          ? { ...novoGasto, id: editingGasto.id, valor: parseFloat(novoGasto.valor) }
          : gasto
      ))
    } else {
      const gasto = {
        ...novoGasto,
        id: Date.now(),
        valor: parseFloat(novoGasto.valor)
      }
      setGastos([...gastos, gasto])
    }
    
    setNovoGasto({
      tipoNome: '',
      valor: '',
      dataPagamento: '',
      categoria: '',
      descricao: ''
    })
    setEditingGasto(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (gasto) => {
    setEditingGasto(gasto)
    setNovoGasto({
      ...gasto,
      valor: gasto.valor.toString()
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setGastos(gastos.filter(gasto => gasto.id !== id))
  }

  const cores = ['#e50914', '#ff6b6b', '#28a745', '#ffc107', '#fd7e14', '#6f42c1', '#17a2b8', '#dc3545']

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Gastos</h1>
          <p className="text-muted-foreground">Controle suas despesas e custos</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0">
              <Plus className="h-4 w-4 mr-2" />
              Novo Gasto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingGasto ? 'Editar Gasto' : 'Novo Gasto'}</DialogTitle>
              <DialogDescription>
                Preencha as informações do gasto
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="tipoNome">Tipo e Nome</Label>
                <Input
                  id="tipoNome"
                  value={novoGasto.tipoNome}
                  onChange={(e) => setNovoGasto({...novoGasto, tipoNome: e.target.value})}
                  placeholder="Ex: Tintas profissionais"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="valor">Valor (R$)</Label>
                <Input
                  id="valor"
                  type="number"
                  step="0.01"
                  value={novoGasto.valor}
                  onChange={(e) => setNovoGasto({...novoGasto, valor: e.target.value})}
                  placeholder="0,00"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dataPagamento">Data de Pagamento</Label>
                <Input
                  id="dataPagamento"
                  type="date"
                  value={novoGasto.dataPagamento}
                  onChange={(e) => setNovoGasto({...novoGasto, dataPagamento: e.target.value})}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="categoria">Categoria</Label>
                <Select value={novoGasto.categoria} onValueChange={(value) => setNovoGasto({...novoGasto, categoria: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="materiais">Materiais</SelectItem>
                    <SelectItem value="tintas">Tintas</SelectItem>
                    <SelectItem value="agulhas">Agulhas</SelectItem>
                    <SelectItem value="cartuchos">Cartuchos</SelectItem>
                    <SelectItem value="aluguel">Aluguel</SelectItem>
                    <SelectItem value="energia">Energia</SelectItem>
                    <SelectItem value="agua">Água</SelectItem>
                    <SelectItem value="internet">Internet</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="equipamentos">Equipamentos</SelectItem>
                    <SelectItem value="manutencao">Manutenção</SelectItem>
                    <SelectItem value="transporte">Transporte</SelectItem>
                    <SelectItem value="alimentacao">Alimentação</SelectItem>
                    <SelectItem value="outros">Outros</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  id="descricao"
                  value={novoGasto.descricao}
                  onChange={(e) => setNovoGasto({...novoGasto, descricao: e.target.value})}
                  placeholder="Descreva o gasto"
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingGasto ? 'Atualizar' : 'Salvar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filtro por Mês */}
      <Card>
        <CardHeader>
          <CardTitle>Filtro por Mês</CardTitle>
        </CardHeader>
        <CardContent>
          <Input
            type="month"
            value={filterMes}
            onChange={(e) => setFilterMes(e.target.value)}
            className="w-full md:w-48"
          />
        </CardContent>
      </Card>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total</CardTitle>
            <TrendingDown className="h-4 w-4 text-expense" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-expense">
              R$ {totalGastos.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Maior Gasto</CardTitle>
            <DollarSign className="h-4 w-4 text-expense" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-expense">
              R$ {maiorGasto.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Menor Gasto</CardTitle>
            <DollarSign className="h-4 w-4 text-expense" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-expense">
              R$ {menorGasto.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Média de Gastos</CardTitle>
            <Calendar className="h-4 w-4 text-expense" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-expense">
              R$ {mediaGastos.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico por Categoria */}
      <Card>
        <CardHeader>
          <CardTitle>Gastos por Categoria</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={dadosGraficoCategoria}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {dadosGraficoCategoria.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={cores[index % cores.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Lista de Gastos */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Gastos</CardTitle>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar gasto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterCategoria} onValueChange={setFilterCategoria}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrar por categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as categorias</SelectItem>
                <SelectItem value="materiais">Materiais</SelectItem>
                <SelectItem value="tintas">Tintas</SelectItem>
                <SelectItem value="agulhas">Agulhas</SelectItem>
                <SelectItem value="cartuchos">Cartuchos</SelectItem>
                <SelectItem value="aluguel">Aluguel</SelectItem>
                <SelectItem value="energia">Energia</SelectItem>
                <SelectItem value="agua">Água</SelectItem>
                <SelectItem value="internet">Internet</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
                <SelectItem value="equipamentos">Equipamentos</SelectItem>
                <SelectItem value="manutencao">Manutenção</SelectItem>
                <SelectItem value="transporte">Transporte</SelectItem>
                <SelectItem value="alimentacao">Alimentação</SelectItem>
                <SelectItem value="outros">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {gastosFiltrados.map((gasto) => (
              <div key={gasto.id} className="border rounded-lg p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="secondary">{gasto.categoria}</Badge>
                    </div>
                    <h3 className="font-semibold">{gasto.tipoNome}</h3>
                    <p className="text-sm text-muted-foreground">{gasto.descricao}</p>
                    <div className="text-sm text-muted-foreground mt-2">
                      Data: {gasto.dataPagamento}
                    </div>
                  </div>
                  <div className="flex flex-col md:items-end mt-4 md:mt-0">
                    <div className="text-lg font-bold text-expense">
                      R$ {gasto.valor.toLocaleString('pt-BR')}
                    </div>
                    <div className="flex space-x-2 mt-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(gasto)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(gasto.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Gastos

