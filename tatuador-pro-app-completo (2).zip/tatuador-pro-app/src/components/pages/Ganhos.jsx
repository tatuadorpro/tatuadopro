import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  TrendingUp,
  DollarSign,
  Calendar,
  Filter
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const Ganhos = () => {
  const [ganhos, setGanhos] = useState([
    {
      id: 1,
      tipo: 'tatuagem',
      cliente: 'João Silva',
      valorTotal: 450.00,
      sinalPago: 150.00,
      formaPagamento: 'pix',
      dataPagamento: '2024-01-20',
      dataAgendamento: '2024-01-25',
      descricao: 'Tatuagem tribal no braço',
      instagram: 'joao_silva',
      email: 'joao@email.com',
      celular: '(11) 99999-9999'
    },
    {
      id: 2,
      tipo: 'curso',
      cliente: 'Maria Santos',
      valorTotal: 800.00,
      sinalPago: 800.00,
      formaPagamento: 'credito',
      dataPagamento: '2024-01-18',
      dataAgendamento: '2024-01-22',
      descricao: 'Curso básico de tatuagem',
      instagram: 'maria_santos',
      email: 'maria@email.com',
      celular: '(11) 88888-8888'
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [filterTipo, setFilterTipo] = useState('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingGanho, setEditingGanho] = useState(null)

  const [novoGanho, setNovoGanho] = useState({
    tipo: '',
    cliente: '',
    valorTotal: '',
    sinalPago: '',
    formaPagamento: '',
    dataPagamento: '',
    dataAgendamento: '',
    descricao: '',
    instagram: '',
    email: '',
    celular: ''
  })

  // Cálculos
  const totalGanhos = ganhos.reduce((sum, ganho) => sum + ganho.valorTotal, 0)
  const totalSinaisPagos = ganhos.reduce((sum, ganho) => sum + ganho.sinalPago, 0)
  const totalAReceber = ganhos.reduce((sum, ganho) => sum + (ganho.valorTotal - ganho.sinalPago), 0)

  // Dados para gráficos
  const ganhosPorTipo = ganhos.reduce((acc, ganho) => {
    acc[ganho.tipo] = (acc[ganho.tipo] || 0) + ganho.valorTotal
    return acc
  }, {})

  const dadosGraficoTipo = Object.entries(ganhosPorTipo).map(([tipo, valor]) => ({
    name: tipo.charAt(0).toUpperCase() + tipo.slice(1),
    value: valor
  }))

  const ganhosPorFormaPagamento = ganhos.reduce((acc, ganho) => {
    acc[ganho.formaPagamento] = (acc[ganho.formaPagamento] || 0) + ganho.valorTotal
    return acc
  }, {})

  const dadosGraficoFormaPagamento = Object.entries(ganhosPorFormaPagamento).map(([forma, valor]) => ({
    name: forma.charAt(0).toUpperCase() + forma.slice(1),
    value: valor
  }))

  // Filtros
  const ganhosFiltrados = ganhos.filter(ganho => {
    const matchesSearch = ganho.cliente.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesTipo = filterTipo === 'todos' || ganho.tipo === filterTipo
    return matchesSearch && matchesTipo
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (editingGanho) {
      setGanhos(ganhos.map(ganho => 
        ganho.id === editingGanho.id 
          ? { ...novoGanho, id: editingGanho.id, valorTotal: parseFloat(novoGanho.valorTotal), sinalPago: parseFloat(novoGanho.sinalPago) }
          : ganho
      ))
    } else {
      const ganho = {
        ...novoGanho,
        id: Date.now(),
        valorTotal: parseFloat(novoGanho.valorTotal),
        sinalPago: parseFloat(novoGanho.sinalPago)
      }
      setGanhos([...ganhos, ganho])
    }
    
    setNovoGanho({
      tipo: '',
      cliente: '',
      valorTotal: '',
      sinalPago: '',
      formaPagamento: '',
      dataPagamento: '',
      dataAgendamento: '',
      descricao: '',
      instagram: '',
      email: '',
      celular: ''
    })
    setEditingGanho(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (ganho) => {
    setEditingGanho(ganho)
    setNovoGanho({
      ...ganho,
      valorTotal: ganho.valorTotal.toString(),
      sinalPago: ganho.sinalPago.toString()
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setGanhos(ganhos.filter(ganho => ganho.id !== id))
  }

  const cores = ['#e50914', '#ff6b6b', '#28a745', '#ffc107', '#fd7e14']

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Ganhos</h1>
          <p className="text-muted-foreground">Gerencie suas receitas e faturamento</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0">
              <Plus className="h-4 w-4 mr-2" />
              Novo Ganho
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingGanho ? 'Editar Ganho' : 'Novo Ganho'}</DialogTitle>
              <DialogDescription>
                Preencha as informações do ganho
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tipo">Tipo</Label>
                  <Select value={novoGanho.tipo} onValueChange={(value) => setNovoGanho({...novoGanho, tipo: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tatuagem">Tatuagem</SelectItem>
                      <SelectItem value="curso">Curso</SelectItem>
                      <SelectItem value="workshop">Workshop</SelectItem>
                      <SelectItem value="piercing">Piercing</SelectItem>
                      <SelectItem value="produto">Produto</SelectItem>
                      <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cliente">Cliente</Label>
                  <Input
                    id="cliente"
                    value={novoGanho.cliente}
                    onChange={(e) => setNovoGanho({...novoGanho, cliente: e.target.value})}
                    placeholder="Nome do cliente"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="valorTotal">Valor Total (R$)</Label>
                  <Input
                    id="valorTotal"
                    type="number"
                    step="0.01"
                    value={novoGanho.valorTotal}
                    onChange={(e) => setNovoGanho({...novoGanho, valorTotal: e.target.value})}
                    placeholder="0,00"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="sinalPago">Sinal Pago (R$)</Label>
                  <Input
                    id="sinalPago"
                    type="number"
                    step="0.01"
                    value={novoGanho.sinalPago}
                    onChange={(e) => setNovoGanho({...novoGanho, sinalPago: e.target.value})}
                    placeholder="0,00"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="formaPagamento">Forma de Pagamento</Label>
                  <Select value={novoGanho.formaPagamento} onValueChange={(value) => setNovoGanho({...novoGanho, formaPagamento: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a forma" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pix">PIX</SelectItem>
                      <SelectItem value="dinheiro">Dinheiro</SelectItem>
                      <SelectItem value="credito">Crédito</SelectItem>
                      <SelectItem value="debito">Débito</SelectItem>
                      <SelectItem value="transferencia">Transferência</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="dataPagamento">Data de Pagamento</Label>
                  <Input
                    id="dataPagamento"
                    type="date"
                    value={novoGanho.dataPagamento}
                    onChange={(e) => setNovoGanho({...novoGanho, dataPagamento: e.target.value})}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="dataAgendamento">Data de Agendamento</Label>
                  <Input
                    id="dataAgendamento"
                    type="date"
                    value={novoGanho.dataAgendamento}
                    onChange={(e) => setNovoGanho({...novoGanho, dataAgendamento: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="instagram">Instagram</Label>
                  <Input
                    id="instagram"
                    value={novoGanho.instagram}
                    onChange={(e) => setNovoGanho({...novoGanho, instagram: e.target.value})}
                    placeholder="@usuario"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={novoGanho.email}
                    onChange={(e) => setNovoGanho({...novoGanho, email: e.target.value})}
                    placeholder="cliente@email.com"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="celular">Celular</Label>
                  <Input
                    id="celular"
                    value={novoGanho.celular}
                    onChange={(e) => setNovoGanho({...novoGanho, celular: e.target.value})}
                    placeholder="(00) 00000-0000"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  id="descricao"
                  value={novoGanho.descricao}
                  onChange={(e) => setNovoGanho({...novoGanho, descricao: e.target.value})}
                  placeholder="Descreva o serviço ou produto"
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingGanho ? 'Atualizar' : 'Salvar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Ganhos</CardTitle>
            <TrendingUp className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {totalGanhos.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Sinais Pagos</CardTitle>
            <DollarSign className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {totalSinaisPagos.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">A Receber</CardTitle>
            <Calendar className="h-4 w-4 text-pending" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pending">
              R$ {totalAReceber.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ganhos por Tipo</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={dadosGraficoTipo}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {dadosGraficoTipo.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={cores[index % cores.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ganhos por Forma de Pagamento</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dadosGraficoFormaPagamento}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                <Bar dataKey="value" fill="#e50914" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Busca */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Ganhos</CardTitle>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por cliente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterTipo} onValueChange={setFilterTipo}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os tipos</SelectItem>
                <SelectItem value="tatuagem">Tatuagem</SelectItem>
                <SelectItem value="curso">Curso</SelectItem>
                <SelectItem value="workshop">Workshop</SelectItem>
                <SelectItem value="piercing">Piercing</SelectItem>
                <SelectItem value="produto">Produto</SelectItem>
                <SelectItem value="outros">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {ganhosFiltrados.map((ganho) => (
              <div key={ganho.id} className="border rounded-lg p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="secondary">{ganho.tipo}</Badge>
                      <Badge variant="outline">{ganho.formaPagamento}</Badge>
                    </div>
                    <h3 className="font-semibold">{ganho.cliente}</h3>
                    <p className="text-sm text-muted-foreground">{ganho.descricao}</p>
                    <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
                      <span>Pagamento: {ganho.dataPagamento}</span>
                      {ganho.dataAgendamento && <span>Agendamento: {ganho.dataAgendamento}</span>}
                    </div>
                  </div>
                  <div className="flex flex-col md:items-end mt-4 md:mt-0">
                    <div className="text-lg font-bold text-gain">
                      R$ {ganho.valorTotal.toLocaleString('pt-BR')}
                    </div>
                    {ganho.sinalPago > 0 && (
                      <div className="text-sm text-muted-foreground">
                        Sinal: R$ {ganho.sinalPago.toLocaleString('pt-BR')}
                      </div>
                    )}
                    {ganho.valorTotal > ganho.sinalPago && (
                      <div className="text-sm text-pending">
                        A receber: R$ {(ganho.valorTotal - ganho.sinalPago).toLocaleString('pt-BR')}
                      </div>
                    )}
                    <div className="flex space-x-2 mt-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(ganho)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(ganho.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Ganhos

