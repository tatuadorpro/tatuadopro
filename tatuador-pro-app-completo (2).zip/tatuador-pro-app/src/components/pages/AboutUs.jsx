import React from 'react';

function AboutUs() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Sobre Nós</h1>
      <p className="text-lg mb-2">Bem-vindo ao nosso aplicativo! Somos dedicados a fornecer as melhores ferramentas para gerenciar seu negócio de tatuagem.</p>
      <p className="text-lg mb-2">Nossa missão é simplificar a gestão de clientes, agendamentos, finanças e estoque, permitindo que você se concentre no que faz de melhor: criar arte.</p>
      <p className="text-lg">Com recursos intuitivos e um design amigável, estamos aqui para ajudar seu estúdio a prosperar.</p>
    </div>
  );
}

export default AboutUs;


