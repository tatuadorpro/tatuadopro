import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart
} from 'recharts'
import { 
  Calendar,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Package,
  FileText
} from 'lucide-react'

const Relatorios = () => {
  const [filtroMes, setFiltroMes] = useState('2024-01')
  const [tipoRelatorio, setTipoRelatorio] = useState('financeiro')

  // Dados simulados para os relatórios
  const dadosFinanceiros = {
    ganhosMensais: [
      { mes: 'Jan', ganhos: 4500, gastos: 1800, lucro: 2700 },
      { mes: 'Fev', ganhos: 5200, gastos: 2100, lucro: 3100 },
      { mes: 'Mar', ganhos: 4800, gastos: 1950, lucro: 2850 },
      { mes: 'Abr', ganhos: 5800, gastos: 2300, lucro: 3500 },
      { mes: 'Mai', ganhos: 6200, gastos: 2450, lucro: 3750 },
      { mes: 'Jun', ganhos: 5900, gastos: 2200, lucro: 3700 }
    ],
    categoriaGastos: [
      { name: 'Materiais', value: 1200, color: '#e50914' },
      { name: 'Aluguel', value: 800, color: '#ff6b6b' },
      { name: 'Energia', value: 300, color: '#28a745' },
      { name: 'Marketing', value: 250, color: '#ffc107' },
      { name: 'Outros', value: 200, color: '#6f42c1' }
    ],
    tipoGanhos: [
      { name: 'Tatuagens', value: 4200, color: '#e50914' },
      { name: 'Piercings', value: 800, color: '#ff6b6b' },
      { name: 'Cursos', value: 1200, color: '#28a745' },
      { name: 'Produtos', value: 300, color: '#ffc107' }
    ]
  }

  const dadosClientes = {
    clientesPorMes: [
      { mes: 'Jan', novos: 8, retorno: 12 },
      { mes: 'Fev', novos: 12, retorno: 15 },
      { mes: 'Mar', novos: 10, retorno: 18 },
      { mes: 'Abr', novos: 15, retorno: 20 },
      { mes: 'Mai', novos: 18, retorno: 22 },
      { mes: 'Jun', novos: 14, retorno: 25 }
    ],
    topClientes: [
      { nome: 'Maria Santos', receita: 2100, sessoes: 5 },
      { nome: 'João Silva', receita: 1250, sessoes: 3 },
      { nome: 'Carlos Oliveira', receita: 850, sessoes: 2 },
      { nome: 'Ana Costa', receita: 750, sessoes: 2 },
      { nome: 'Pedro Lima', receita: 600, sessoes: 1 }
    ]
  }

  const dadosEstoque = {
    movimentacao: [
      { mes: 'Jan', entradas: 15, saidas: 12 },
      { mes: 'Fev', entradas: 8, saidas: 18 },
      { mes: 'Mar', entradas: 20, saidas: 15 },
      { mes: 'Abr', entradas: 12, saidas: 20 },
      { mes: 'Mai', entradas: 25, saidas: 22 },
      { mes: 'Jun', entradas: 10, saidas: 16 }
    ],
    categorias: [
      { name: 'Tintas', quantidade: 45, valor: 1125 },
      { name: 'Agulhas', quantidade: 150, valor: 675 },
      { name: 'Cartuchos', quantidade: 80, valor: 560 },
      { name: 'Luvas', quantidade: 200, valor: 360 },
      { name: 'Equipamentos', quantidade: 5, valor: 2250 }
    ]
  }

  const dadosProducao = {
    trabalhosPorMes: [
      { mes: 'Jan', tatuagens: 25, piercings: 8, cursos: 2 },
      { mes: 'Fev', tatuagens: 30, piercings: 12, cursos: 3 },
      { mes: 'Mar', tatuagens: 28, piercings: 10, cursos: 2 },
      { mes: 'Abr', tatuagens: 35, piercings: 15, cursos: 4 },
      { mes: 'Mai', tatuagens: 38, piercings: 18, cursos: 3 },
      { mes: 'Jun', tatuagens: 32, piercings: 14, cursos: 2 }
    ],
    estilosMaisPopulares: [
      { name: 'Realismo', quantidade: 45, color: '#e50914' },
      { name: 'Tribal', quantidade: 32, color: '#ff6b6b' },
      { name: 'Old School', quantidade: 28, color: '#28a745' },
      { name: 'Geométrico', quantidade: 25, color: '#ffc107' },
      { name: 'Outros', quantidade: 20, color: '#6f42c1' }
    ]
  }



  const cores = ['#e50914', '#ff6b6b', '#28a745', '#ffc107', '#fd7e14', '#6f42c1', '#17a2b8', '#dc3545']

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Relatórios</h1>
          <p className="text-muted-foreground">Análise completa do seu negócio</p>
        </div>
        <div className="flex space-x-2 mt-4 md:mt-0">
          <Input
            type="month"
            value={filtroMes}
            onChange={(e) => setFiltroMes(e.target.value)}
            className="w-48"
          />
        </div>
      </div>

      <Tabs value={tipoRelatorio} onValueChange={setTipoRelatorio}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
          <TabsTrigger value="clientes">Clientes</TabsTrigger>
          <TabsTrigger value="estoque">Estoque</TabsTrigger>
          <TabsTrigger value="producao">Produção</TabsTrigger>
        </TabsList>

        {/* Relatório Financeiro */}
        <TabsContent value="financeiro" className="space-y-6">
          {/* Resumo Financeiro */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
                <TrendingUp className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gain">R$ 32.400</div>
                <p className="text-xs text-muted-foreground">+12% vs mês anterior</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Gastos Totais</CardTitle>
                <TrendingDown className="h-4 w-4 text-expense" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-expense">R$ 12.800</div>
                <p className="text-xs text-muted-foreground">+5% vs mês anterior</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Lucro Líquido</CardTitle>
                <DollarSign className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gain">R$ 19.600</div>
                <p className="text-xs text-muted-foreground">+18% vs mês anterior</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Margem de Lucro</CardTitle>
                <TrendingUp className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">60.5%</div>
                <p className="text-xs text-muted-foreground">+3% vs mês anterior</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráfico de Evolução Financeira */}
          <Card>
            <CardHeader>
              <CardTitle>Evolução Financeira</CardTitle>
              <CardDescription>Ganhos, gastos e lucro por mês</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={dadosFinanceiros.ganhosMensais}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                  <Area type="monotone" dataKey="ganhos" stackId="1" stroke="#28a745" fill="#28a745" fillOpacity={0.6} />
                  <Area type="monotone" dataKey="gastos" stackId="2" stroke="#e50914" fill="#e50914" fillOpacity={0.6} />
                  <Area type="monotone" dataKey="lucro" stackId="3" stroke="#ffc107" fill="#ffc107" fillOpacity={0.6} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Gráficos de Pizza */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Gastos por Categoria</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={dadosFinanceiros.categoriaGastos}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {dadosFinanceiros.categoriaGastos.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Receita por Tipo de Serviço</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={dadosFinanceiros.tipoGanhos}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {dadosFinanceiros.tipoGanhos.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Relatório de Clientes */}
        <TabsContent value="clientes" className="space-y-6">
          {/* Resumo de Clientes */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
                <Users className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">127</div>
                <p className="text-xs text-muted-foreground">+15 novos este mês</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Clientes Ativos</CardTitle>
                <Users className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gain">89</div>
                <p className="text-xs text-muted-foreground">70% do total</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Taxa de Retorno</CardTitle>
                <TrendingUp className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">65%</div>
                <p className="text-xs text-muted-foreground">+8% vs mês anterior</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Ticket Médio</CardTitle>
                <DollarSign className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gain">R$ 385</div>
                <p className="text-xs text-muted-foreground">+12% vs mês anterior</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráfico de Clientes */}
          <Card>
            <CardHeader>
              <CardTitle>Evolução de Clientes</CardTitle>
              <CardDescription>Novos clientes vs clientes de retorno</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dadosClientes.clientesPorMes}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="novos" fill="#e50914" name="Novos Clientes" />
                  <Bar dataKey="retorno" fill="#28a745" name="Clientes de Retorno" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Clientes */}
          <Card>
            <CardHeader>
              <CardTitle>Top 5 Clientes</CardTitle>
              <CardDescription>Clientes que mais geraram receita</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dadosClientes.topClientes.map((cliente, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Badge variant="secondary">#{index + 1}</Badge>
                      <div>
                        <p className="font-medium">{cliente.nome}</p>
                        <p className="text-sm text-muted-foreground">{cliente.sessoes} sessões</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gain">R$ {cliente.receita.toLocaleString('pt-BR')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Relatório de Estoque */}
        <TabsContent value="estoque" className="space-y-6">
          {/* Resumo de Estoque */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Itens em Estoque</CardTitle>
                <Package className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">480</div>
                <p className="text-xs text-muted-foreground">15 categorias</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Valor do Estoque</CardTitle>
                <DollarSign className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gain">R$ 4.970</div>
                <p className="text-xs text-muted-foreground">Valor total investido</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Itens em Falta</CardTitle>
                <TrendingDown className="h-4 w-4 text-expense" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-expense">3</div>
                <p className="text-xs text-muted-foreground">Necessita reposição</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Giro de Estoque</CardTitle>
                <TrendingUp className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">2.3x</div>
                <p className="text-xs text-muted-foreground">Por mês</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráfico de Movimentação */}
          <Card>
            <CardHeader>
              <CardTitle>Movimentação de Estoque</CardTitle>
              <CardDescription>Entradas vs saídas por mês</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={dadosEstoque.movimentacao}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="entradas" stroke="#28a745" strokeWidth={2} name="Entradas" />
                  <Line type="monotone" dataKey="saidas" stroke="#e50914" strokeWidth={2} name="Saídas" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Estoque por Categoria */}
          <Card>
            <CardHeader>
              <CardTitle>Estoque por Categoria</CardTitle>
              <CardDescription>Quantidade e valor por categoria</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dadosEstoque.categorias.map((categoria, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{categoria.name}</p>
                      <p className="text-sm text-muted-foreground">{categoria.quantidade} itens</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gain">R$ {categoria.valor.toLocaleString('pt-BR')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Relatório de Produção */}
        <TabsContent value="producao" className="space-y-6">
          {/* Resumo de Produção */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Trabalhos Realizados</CardTitle>
                <FileText className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">188</div>
                <p className="text-xs text-muted-foreground">Últimos 6 meses</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Média Mensal</CardTitle>
                <Calendar className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">31</div>
                <p className="text-xs text-muted-foreground">Trabalhos por mês</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tempo Médio</CardTitle>
                <Calendar className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3.2h</div>
                <p className="text-xs text-muted-foreground">Por trabalho</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Produtividade</CardTitle>
                <TrendingUp className="h-4 w-4 text-gain" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gain">+15%</div>
                <p className="text-xs text-muted-foreground">vs mês anterior</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráfico de Produção */}
          <Card>
            <CardHeader>
              <CardTitle>Produção por Tipo de Serviço</CardTitle>
              <CardDescription>Quantidade de trabalhos realizados por mês</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dadosProducao.trabalhosPorMes}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="tatuagens" fill="#e50914" name="Tatuagens" />
                  <Bar dataKey="piercings" fill="#28a745" name="Piercings" />
                  <Bar dataKey="cursos" fill="#ffc107" name="Cursos" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Estilos Mais Populares */}
          <Card>
            <CardHeader>
              <CardTitle>Estilos Mais Populares</CardTitle>
              <CardDescription>Distribuição por estilo de tatuagem</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={dadosProducao.estilosMaisPopulares}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="quantidade"
                  >
                    {dadosProducao.estilosMaisPopulares.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default Relatorios

