import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Package,
  AlertTriangle,
  DollarSign,
  Calendar,
  TrendingDown
} from 'lucide-react'

const Estoque = () => {
  const [itens, setItens] = useState([
    {
      id: 1,
      categoria: 'tinta',
      nome: 'Tinta Preta Profissional',
      unidade: 'frasco',
      precoUnitario: 25.00,
      quantidade: 15,
      fornecedor: 'Tattoo Supply Co.',
      dataCompra: '2024-01-10',
      dataVencimento: '2025-01-10',
      descricao: 'Tinta preta de alta qualidade para tatuagem',
      quantidadeMinima: 5
    },
    {
      id: 2,
      categoria: 'agulhas',
      nome: 'Agulhas Descartáveis 7RL',
      unidade: 'caixa',
      precoUnitario: 45.00,
      quantidade: 3,
      fornecedor: 'Medical Supplies Ltd.',
      dataCompra: '2024-01-05',
      dataVencimento: null,
      descricao: 'Caixa com 50 agulhas descartáveis 7RL',
      quantidadeMinima: 2
    },
    {
      id: 3,
      categoria: 'cartuchos',
      nome: 'Cartuchos 5RL',
      unidade: 'pacote',
      precoUnitario: 35.00,
      quantidade: 8,
      fornecedor: 'Pro Tattoo Equipment',
      dataCompra: '2024-01-15',
      dataVencimento: null,
      descricao: 'Pacote com 20 cartuchos 5RL',
      quantidadeMinima: 10
    },
    {
      id: 4,
      categoria: 'luvas',
      nome: 'Luvas Nitrílicas',
      unidade: 'caixa',
      precoUnitario: 18.00,
      quantidade: 2,
      fornecedor: 'Safety First',
      dataCompra: '2024-01-08',
      dataVencimento: '2026-01-08',
      descricao: 'Caixa com 100 luvas nitrílicas descartáveis',
      quantidadeMinima: 5
    },
    {
      id: 5,
      categoria: 'equipamentos',
      nome: 'Máquina Rotativa',
      unidade: 'unidade',
      precoUnitario: 450.00,
      quantidade: 1,
      fornecedor: 'Tattoo Machines Pro',
      dataCompra: '2023-12-20',
      dataVencimento: null,
      descricao: 'Máquina rotativa profissional para tatuagem',
      quantidadeMinima: 1
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategoria, setFilterCategoria] = useState('todas')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingItem, setEditingItem] = useState(null)

  const [novoItem, setNovoItem] = useState({
    categoria: '',
    nome: '',
    unidade: '',
    precoUnitario: '',
    quantidade: '',
    fornecedor: '',
    dataCompra: '',
    dataVencimento: '',
    descricao: "",
    quantidadeMinima: ""
  })

  // Categorias disponíveis
  const categorias = [
    'tinta', 'agulhas', 'cartuchos', 'luvas', 'descartáveis', 
    'equipamentos', 'higiene', 'acessórios', 'outros'
  ]

  // Unidades disponíveis
  const unidades = ['caixa', 'pacote', 'frasco', 'ml', 'gramas', 'unidade']

  // Cálculos
  const totalItens = itens.length
  const itensEmFalta = itens.filter(item => item.quantidade === 0).length
  const estoquesBaixos = itens.filter(item => item.quantidade > 0 && item.quantidade <= item.quantidadeMinima).length
  const valorTotalEstoque = itens.reduce((sum, item) => sum + (item.precoUnitario * item.quantidade), 0)

  // Filtros
  const itensFiltrados = itens.filter(item => {
    const matchesSearch = item.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.fornecedor.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategoria = filterCategoria === 'todas' || item.categoria === filterCategoria
    return matchesSearch && matchesCategoria
  })

  // Verificar se está próximo do vencimento (30 dias)
  const isProximoVencimento = (dataVencimento) => {
    if (!dataVencimento) return false
    const hoje = new Date()
    const vencimento = new Date(dataVencimento)
    const diffTime = vencimento - hoje
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays <= 30 && diffDays > 0
  }

  const isVencido = (dataVencimento) => {
    if (!dataVencimento) return false
    const hoje = new Date()
    const vencimento = new Date(dataVencimento)
    return vencimento < hoje
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (editingItem) {
      setItens(itens.map(item => 
        item.id === editingItem.id 
          ? { 
              ...novoItem, 
              id: editingItem.id, 
              precoUnitario: parseFloat(novoItem.precoUnitario),
              quantidade: parseInt(novoItem.quantidade) || 0,
              quantidadeMinima: parseInt(novoItem.quantidadeMinima) || 0
            }
          : item
      ))
    } else {
      const item = {
        ...novoItem,
        id: Date.now(),
        precoUnitario: parseFloat(novoItem.precoUnitario),
        quantidade: parseInt(novoItem.quantidade) || 0,
        quantidadeMinima: parseInt(novoItem.quantidadeMinima) || 0
      }
      setItens([...itens, item])
    }
    
    setNovoItem({
      categoria: '',
      nome: '',
      unidade: '',
      precoUnitario: '',
      quantidade: '',
      fornecedor: '',
      dataCompra: '',
      dataVencimento: '',
      descricao: "",
      quantidadeMinima: ""
    })
    setEditingItem(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (item) => {
    setEditingItem(item)
    setNovoItem({
      ...item,
      precoUnitario: item.precoUnitario.toString(),
      quantidade: item.quantidade.toString(),
      quantidadeMinima: item.quantidadeMinima.toString()
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setItens(itens.filter(item => item.id !== id))
  }

  const getStatusBadge = (item) => {
    if (item.quantidade === 0) {
      return <Badge variant="destructive">Em Falta</Badge>
    } else if (item.quantidade <= item.quantidadeMinima) {
      return <Badge className="bg-low-stock">Estoque Baixo</Badge>
    } else if (isVencido(item.dataVencimento)) {
      return <Badge variant="destructive">Vencido</Badge>
    } else if (isProximoVencimento(item.dataVencimento)) {
      return <Badge className="bg-pending">Próximo ao Vencimento</Badge>
    }
    return <Badge variant="secondary">OK</Badge>
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Estoque</h1>
          <p className="text-muted-foreground">Gerencie seus materiais e equipamentos</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0">
              <Plus className="h-4 w-4 mr-2" />
              Novo Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar Item' : 'Novo Item'}</DialogTitle>
              <DialogDescription>
                Adicione um item ao estoque
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="categoria">Categoria</Label>
                  <Select value={novoItem.categoria} onValueChange={(value) => setNovoItem({...novoItem, categoria: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      {categorias.map(categoria => (
                        <SelectItem key={categoria} value={categoria}>
                          {categoria.charAt(0).toUpperCase() + categoria.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="nome-item">Nome do Item</Label>
                  <Input
                    id="nome-item"
                    value={novoItem.nome}
                    onChange={(e) => setNovoItem({...novoItem, nome: e.target.value})}
                    placeholder="Nome do item"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="unidade">Unidade</Label>
                  <Select value={novoItem.unidade} onValueChange={(value) => setNovoItem({...novoItem, unidade: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a unidade" />
                    </SelectTrigger>
                    <SelectContent>
                      {unidades.map(unidade => (
                        <SelectItem key={unidade} value={unidade}>
                          {unidade.charAt(0).toUpperCase() + unidade.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="preco-unitario">Preço Unitário (R$)</Label>
                  <Input
                    id="preco-unitario"
                    type="number"
                    step="0.01"
                    value={novoItem.precoUnitario}
                    onChange={(e) => setNovoItem({...novoItem, precoUnitario: e.target.value})}
                    placeholder="0,00"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="quantidade">Quantidade</Label>
                  <Input
                    id="quantidade"
                    type="number"
                    value={novoItem.quantidade}
                    onChange={(e) => setNovoItem({...novoItem, quantidade: e.target.value})}
                    placeholder="0"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fornecedor">Fornecedor</Label>
                  <Input
                    id="fornecedor"
                    value={novoItem.fornecedor}
                    onChange={(e) => setNovoItem({...novoItem, fornecedor: e.target.value})}
                    placeholder="Nome do fornecedor"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data-compra">Data da Compra</Label>
                  <Input
                    id="data-compra"
                    type="date"
                    value={novoItem.dataCompra}
                    onChange={(e) => setNovoItem({...novoItem, dataCompra: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data-vencimento">Data de Vencimento</Label>
                  <Input
                    id="data-vencimento"
                    type="date"
                    value={novoItem.dataVencimento}
                    onChange={(e) => setNovoItem({...novoItem, dataVencimento: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="quantidade-minima">Quantidade Mínima</Label>
                  <Input
                    id="quantidade-minima"
                    type="number"
                    value={novoItem.quantidadeMinima}
                    onChange={(e) => setNovoItem({...novoItem, quantidadeMinima: e.target.value})}
                    placeholder="0"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao-item">Descrição</Label>
                <Textarea
                  id="descricao-item"
                  value={novoItem.descricao}
                  onChange={(e) => setNovoItem({...novoItem, descricao: e.target.value})}
                  placeholder="Descrição do item"
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingItem ? 'Atualizar' : 'Salvar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Itens</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalItens}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Itens em Falta</CardTitle>
            <TrendingDown className="h-4 w-4 text-expense" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-expense">{itensEmFalta}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estoque Baixo</CardTitle>
            <AlertTriangle className="h-4 w-4 text-low-stock" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-low-stock">{estoquesBaixos}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <DollarSign className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {valorTotalEstoque.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alertas */}
      {(itensEmFalta > 0 || estoquesBaixos > 0) && (
        <Card className="border-low-stock">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-low-stock">
              <AlertTriangle className="h-5 w-5" />
              <span>Alertas de Estoque</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {itensEmFalta > 0 && (
                <p className="text-sm">
                  <span className="font-semibold text-expense">{itensEmFalta}</span> item(ns) em falta
                </p>
              )}
              {estoquesBaixos > 0 && (
                <p className="text-sm">
                  <span className="font-semibold text-low-stock">{estoquesBaixos}</span> item(ns) com estoque baixo
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lista de Itens */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Itens</CardTitle>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar itens..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterCategoria} onValueChange={setFilterCategoria}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrar por categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as categorias</SelectItem>
                {categorias.map(categoria => (
                  <SelectItem key={categoria} value={categoria}>
                    {categoria.charAt(0).toUpperCase() + categoria.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {itensFiltrados.map((item) => (
              <div key={item.id} className="border rounded-lg p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="secondary">{item.categoria}</Badge>
                      {getStatusBadge(item)}
                    </div>
                    <h3 className="font-semibold">{item.nome}</h3>
                    <p className="text-sm text-muted-foreground">{item.descricao}</p>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-3 text-sm">
                      <div>
                        <span className="text-muted-foreground">Quantidade:</span>
                        <div className={`font-medium ${
                          item.quantidade === 0 ? 'text-expense' : 
                          item.quantidade <= item.quantidadeMinima ? 'text-low-stock' : 'text-foreground'
                        }`}>
                          {item.quantidade} {item.unidade}
                        </div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Qtd. Mínima:</span>
                        <div className="font-medium">{item.quantidadeMinima}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Preço Unit.:</span>
                        <div className="font-medium">R$ {item.precoUnitario.toLocaleString('pt-BR')}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Fornecedor:</span>
                        <div className="font-medium">{item.fornecedor}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Compra:</span>
                        <div className="font-medium">{item.dataCompra}</div>
                      </div>
                    </div>
                    {item.dataVencimento && (
                      <div className="mt-2 text-sm">
                        <span className="text-muted-foreground">Vencimento:</span>
                        <span className={`ml-1 font-medium ${
                          isVencido(item.dataVencimento) ? 'text-expense' :
                          isProximoVencimento(item.dataVencimento) ? 'text-pending' : 'text-foreground'
                        }`}>
                          {item.dataVencimento}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col md:items-end mt-4 md:mt-0">
                    <div className="text-lg font-bold text-gain">
                      R$ {(item.precoUnitario * item.quantidade).toLocaleString('pt-BR')}
                    </div>
                    <div className="text-sm text-muted-foreground">Valor total</div>
                    <div className="flex space-x-2 mt-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(item)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(item.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {itensFiltrados.length === 0 && (
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhum item encontrado</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default Estoque

