import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Store,
  Settings,
  Share,
  Package,
  DollarSign,
  Eye,
  EyeOff,
  ShoppingCart
} from 'lucide-react'

const Loja = () => {
  const [configLoja, setConfigLoja] = useState({
    nome: 'ART TATTOO STORE',
    whatsapp: '+5553999621044',
    instagram: 'alex_souza_tattoo',
    descricao: 'Loja oficial do estúdio ART TATTOO. Tatuagens, piercings, cursos e produtos de qualidade.',
    ativa: true
  })

  const [produtos, setProdutos] = useState([
    {
      id: 1,
      tipo: 'tatuagem',
      nome: 'Tatuagem Pequena (5-10cm)',
      categoria: 'Tatuagens',
      preco: 150.00,
      precoPromocional: null,
      estoque: 0,
      imagemUrl: '',
      descricao: 'Tatuagem personalizada de 5 a 10 centímetros',
      disponivel: true
    },
    {
      id: 2,
      tipo: 'curso',
      nome: 'Curso Básico de Tatuagem',
      categoria: 'Cursos',
      preco: 800.00,
      precoPromocional: 650.00,
      estoque: 5,
      imagemUrl: '',
      descricao: 'Curso completo para iniciantes na arte da tatuagem',
      disponivel: true
    },
    {
      id: 3,
      tipo: 'produto',
      nome: 'Kit de Cuidados Pós-Tatuagem',
      categoria: 'Produtos',
      preco: 45.00,
      precoPromocional: null,
      estoque: 20,
      imagemUrl: '',
      descricao: 'Kit completo para cuidados após a tatuagem',
      disponivel: true
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [filterTipo, setFilterTipo] = useState('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false)
  const [editingProduto, setEditingProduto] = useState(null)
  const [imagemModal, setImagemModal] = useState({aberto: false, produto: null})

  const [novoProduto, setNovoProduto] = useState({
    tipo: '',
    nome: '',
    categoria: '',
    preco: '',
    precoPromocional: '',
    estoque: '',
    imagemUrl: '',
    descricao: '',
    disponivel: true
  })

  // Filtros
  const produtosFiltrados = produtos.filter(produto => {
    const matchesSearch = produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         produto.categoria.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesTipo = filterTipo === 'todos' || produto.tipo === filterTipo
    return matchesSearch && matchesTipo
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (editingProduto) {
      setProdutos(produtos.map(produto => 
        produto.id === editingProduto.id 
          ? { 
              ...novoProduto, 
              id: editingProduto.id, 
              preco: parseFloat(novoProduto.preco),
              precoPromocional: novoProduto.precoPromocional ? parseFloat(novoProduto.precoPromocional) : null,
              estoque: parseInt(novoProduto.estoque) || 0
            }
          : produto
      ))
    } else {
      const produto = {
        ...novoProduto,
        id: Date.now(),
        preco: parseFloat(novoProduto.preco),
        precoPromocional: novoProduto.precoPromocional ? parseFloat(novoProduto.precoPromocional) : null,
        estoque: parseInt(novoProduto.estoque) || 0
      }
      setProdutos([...produtos, produto])
    }
    
    setNovoProduto({
      tipo: '',
      nome: '',
      categoria: '',
      preco: '',
      precoPromocional: '',
      estoque: '',
      imagemUrl: '',
      descricao: '',
      disponivel: true
    })
    setEditingProduto(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (produto) => {
    setEditingProduto(produto)
    setNovoProduto({
      ...produto,
      preco: produto.preco.toString(),
      precoPromocional: produto.precoPromocional ? produto.precoPromocional.toString() : '',
      estoque: produto.estoque.toString()
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setProdutos(produtos.filter(produto => produto.id !== id))
  }

  const toggleDisponibilidade = (id) => {
    setProdutos(produtos.map(produto => 
      produto.id === id 
        ? { ...produto, disponivel: !produto.disponivel }
        : produto
    ))
  }

  const gerarLinkLoja = () => {
    // Abrir loja pública em nova aba
    window.open('/loja-publica', '_blank')
  }

  const precoFinal = (produto) => {
    return produto.precoPromocional || produto.preco
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Loja Virtual</h1>
          <p className="text-muted-foreground">Gerencie sua loja online</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Dialog open={isConfigDialogOpen} onOpenChange={setIsConfigDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full sm:w-auto">
                <Settings className="h-4 w-4 mr-2" />
                Configurar Loja
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Configurações da Loja</DialogTitle>
                <DialogDescription>
                  Configure as informações da sua loja virtual
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nome-loja">Nome da Loja</Label>
                  <Input
                    id="nome-loja"
                    value={configLoja.nome}
                    onChange={(e) => setConfigLoja({...configLoja, nome: e.target.value})}
                    placeholder="Nome da sua loja"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="whatsapp-loja">WhatsApp</Label>
                  <Input
                    id="whatsapp-loja"
                    value={configLoja.whatsapp}
                    onChange={(e) => setConfigLoja({...configLoja, whatsapp: e.target.value})}
                    placeholder="+55 53 99999-9999"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="instagram-loja">Instagram</Label>
                  <Input
                    id="instagram-loja"
                    value={configLoja.instagram}
                    onChange={(e) => setConfigLoja({...configLoja, instagram: e.target.value})}
                    placeholder="seu_usuario"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="descricao-loja">Descrição</Label>
                  <Textarea
                    id="descricao-loja"
                    value={configLoja.descricao}
                    onChange={(e) => setConfigLoja({...configLoja, descricao: e.target.value})}
                    placeholder="Descrição da sua loja"
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="loja-ativa"
                    checked={configLoja.ativa}
                    onCheckedChange={(checked) => setConfigLoja({...configLoja, ativa: checked})}
                  />
                  <Label htmlFor="loja-ativa">Loja ativa</Label>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsConfigDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={() => setIsConfigDialogOpen(false)}>
                    Salvar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button onClick={gerarLinkLoja} className="w-full sm:w-auto">
            <Share className="h-4 w-4 mr-2" />
            Compartilhar Loja
          </Button>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Plus className="h-4 w-4 mr-2" />
                Novo Produto
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProduto ? 'Editar Produto' : 'Novo Produto'}</DialogTitle>
                <DialogDescription>
                  Preencha as informações do produto
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tipo">Tipo</Label>
                    <Select value={novoProduto.tipo} onValueChange={(value) => setNovoProduto({...novoProduto, tipo: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="tatuagem">Tatuagem</SelectItem>
                        <SelectItem value="piercing">Piercing</SelectItem>
                        <SelectItem value="curso">Curso</SelectItem>
                        <SelectItem value="workshop">Workshop</SelectItem>
                        <SelectItem value="produto">Produto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="categoria">Categoria</Label>
                    <Input
                      id="categoria"
                      value={novoProduto.categoria}
                      onChange={(e) => setNovoProduto({...novoProduto, categoria: e.target.value})}
                      placeholder="Ex: Tatuagens, Cursos"
                    />
                  </div>
                  
                  <div className="md:col-span-2 space-y-2">
                    <Label htmlFor="nome-produto">Nome do Produto</Label>
                    <Input
                      id="nome-produto"
                      value={novoProduto.nome}
                      onChange={(e) => setNovoProduto({...novoProduto, nome: e.target.value})}
                      placeholder="Nome do produto ou serviço"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="preco">Preço (R$)</Label>
                    <Input
                      id="preco"
                      type="number"
                      step="0.01"
                      value={novoProduto.preco}
                      onChange={(e) => setNovoProduto({...novoProduto, preco: e.target.value})}
                      placeholder="0,00"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="preco-promocional">Preço Promocional (R$)</Label>
                    <Input
                      id="preco-promocional"
                      type="number"
                      step="0.01"
                      value={novoProduto.precoPromocional}
                      onChange={(e) => setNovoProduto({...novoProduto, precoPromocional: e.target.value})}
                      placeholder="0,00 (opcional)"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="estoque">Estoque</Label>
                    <Input
                      id="estoque"
                      type="number"
                      value={novoProduto.estoque}
                      onChange={(e) => setNovoProduto({...novoProduto, estoque: e.target.value})}
                      placeholder="0"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="imagem-url">Imagem do Produto</Label>
                    <div className="space-y-2">
                      <Input
                        id="imagem-url"
                        value={novoProduto.imagemUrl}
                        onChange={(e) => setNovoProduto({...novoProduto, imagemUrl: e.target.value})}
                        placeholder="https://exemplo.com/imagem.jpg"
                      />
                      <div className="flex gap-2">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (e) => {
                                setNovoProduto({...novoProduto, imagemUrl: e.target.result});
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                          className="hidden"
                          id="upload-image"
                        />
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => document.getElementById('upload-image').click()}
                          className="flex-1"
                        >
                          Escolher da Galeria
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="descricao-produto">Descrição</Label>
                  <Textarea
                    id="descricao-produto"
                    value={novoProduto.descricao}
                    onChange={(e) => setNovoProduto({...novoProduto, descricao: e.target.value})}
                    placeholder="Descrição detalhada do produto"
                    rows={4}
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="disponivel"
                    checked={novoProduto.disponivel}
                    onCheckedChange={(checked) => setNovoProduto({...novoProduto, disponivel: checked})}
                  />
                  <Label htmlFor="disponivel">Produto disponível</Label>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    {editingProduto ? 'Atualizar' : 'Salvar'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Status da Loja */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Store className="h-5 w-5" />
            <span>{configLoja.nome}</span>
            <Badge variant={configLoja.ativa ? "default" : "secondary"}>
              {configLoja.ativa ? "Ativa" : "Inativa"}
            </Badge>
          </CardTitle>
          <CardDescription>{configLoja.descricao}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <Package className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Total de produtos: {produtos.length}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Eye className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Disponíveis: {produtos.filter(p => p.disponivel).length}</span>
            </div>
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Preço médio: R$ {(produtos.reduce((sum, p) => sum + precoFinal(p), 0) / produtos.length || 0).toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle>Produtos da Loja</CardTitle>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar produtos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterTipo} onValueChange={setFilterTipo}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os tipos</SelectItem>
                <SelectItem value="tatuagem">Tatuagem</SelectItem>
                <SelectItem value="piercing">Piercing</SelectItem>
                <SelectItem value="curso">Curso</SelectItem>
                <SelectItem value="workshop">Workshop</SelectItem>
                <SelectItem value="produto">Produto</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {produtosFiltrados.map((produto) => (
              <Card key={produto.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">{produto.tipo}</Badge>
                    <div className="flex space-x-1">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => toggleDisponibilidade(produto.id)}
                      >
                        {produto.disponivel ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleEdit(produto)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(produto.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{produto.nome}</CardTitle>
                  <CardDescription>{produto.categoria}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {produto.imagemUrl && (
                    <div className="w-full aspect-square bg-muted rounded-lg flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity"
                         onClick={() => setImagemModal({aberto: true, produto})}>
                      <img 
                        src={produto.imagemUrl} 
                        alt={produto.nome}
                        className="w-full h-full object-cover rounded-lg"
                        onError={(e) => {
                          e.target.style.display = 'none'
                          e.target.nextSibling.style.display = 'flex'
                        }}
                      />
                      <div className="hidden items-center justify-center text-muted-foreground">
                        <Package className="h-8 w-8" />
                      </div>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Preço:</span>
                      <div className="text-right">
                        {produto.precoPromocional ? (
                          <>
                            <div className="text-lg font-bold text-gain">
                              R$ {produto.precoPromocional.toLocaleString('pt-BR')}
                            </div>
                            <div className="text-sm text-muted-foreground line-through">
                              R$ {produto.preco.toLocaleString('pt-BR')}
                            </div>
                          </>
                        ) : (
                          <div className="text-lg font-bold">
                            R$ {produto.preco.toLocaleString('pt-BR')}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Estoque:</span>
                      <span className="text-sm font-medium">{produto.estoque}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Status:</span>
                      <Badge variant={produto.disponivel ? "default" : "secondary"}>
                        {produto.disponivel ? "Disponível" : "Indisponível"}
                      </Badge>
                    </div>
                  </div>
                  
                  <p className="text-sm text-muted-foreground line-clamp-3">
                    {produto.descricao}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {produtosFiltrados.length === 0 && (
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhum produto encontrado</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Visualização de Imagem */}
      <Dialog open={imagemModal.aberto} onOpenChange={(aberto) => setImagemModal({aberto, produto: null})}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>{imagemModal.produto?.nome}</DialogTitle>
            <DialogDescription>{imagemModal.produto?.categoria}</DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-center">
            {imagemModal.produto?.imagemUrl && (
              <img 
                src={imagemModal.produto.imagemUrl} 
                alt={imagemModal.produto.nome}
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            )}
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Preço:</span>
              <div className="text-right">
                {imagemModal.produto?.precoPromocional ? (
                  <>
                    <div className="text-lg font-bold text-gain">
                      R$ {imagemModal.produto.precoPromocional.toLocaleString('pt-BR')}
                    </div>
                    <div className="text-sm text-muted-foreground line-through">
                      R$ {imagemModal.produto.preco.toLocaleString('pt-BR')}
                    </div>
                  </>
                ) : (
                  <div className="text-lg font-bold">
                    R$ {imagemModal.produto?.preco.toLocaleString('pt-BR')}
                  </div>
                )}
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              {imagemModal.produto?.descricao}
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default Loja

