import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  Plus, 
  Minus,
  Search, 
  Store,
  Package,
  ShoppingCart,
  Trash2,
  MessageCircle,
  Instagram,
  X
} from 'lucide-react'

const LojaPublica = ({ configLoja, produtos }) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [carrinho, setCarrinho] = useState([])
  const [isCarrinhoOpen, setIsCarrinhoOpen] = useState(false)
  const [imagemModal, setImagemModal] = useState({aberto: false, produto: null})

  // Filtrar produtos disponíveis
  const produtosDisponiveis = produtos.filter(produto => produto.disponivel)
  
  // Filtrar por busca
  const produtosFiltrados = produtosDisponiveis.filter(produto => 
    produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    produto.categoria.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const adicionarAoCarrinho = (produto) => {
    const itemExistente = carrinho.find(item => item.id === produto.id)
    
    if (itemExistente) {
      setCarrinho(carrinho.map(item => 
        item.id === produto.id 
          ? { ...item, quantidade: item.quantidade + 1 }
          : item
      ))
    } else {
      setCarrinho([...carrinho, { ...produto, quantidade: 1 }])
    }
  }

  const removerDoCarrinho = (produtoId) => {
    setCarrinho(carrinho.filter(item => item.id !== produtoId))
  }

  const alterarQuantidade = (produtoId, novaQuantidade) => {
    if (novaQuantidade <= 0) {
      removerDoCarrinho(produtoId)
      return
    }
    
    setCarrinho(carrinho.map(item => 
      item.id === produtoId 
        ? { ...item, quantidade: novaQuantidade }
        : item
    ))
  }

  const calcularTotal = () => {
    return carrinho.reduce((total, item) => {
      const preco = item.precoPromocional || item.preco
      return total + (preco * item.quantidade)
    }, 0)
  }

  const enviarParaWhatsApp = () => {
    if (carrinho.length === 0) {
      alert('Adicione produtos ao carrinho antes de enviar!')
      return
    }

    let mensagem = `🛍️ *Pedido da ${configLoja.nome}*\n\n`
    
    carrinho.forEach(item => {
      const preco = item.precoPromocional || item.preco
      mensagem += `📦 *${item.nome}*\n`
      mensagem += `   Quantidade: ${item.quantidade}\n`
      mensagem += `   Preço unitário: R$ ${preco.toFixed(2)}\n`
      mensagem += `   Subtotal: R$ ${(preco * item.quantidade).toFixed(2)}\n\n`
    })
    
    mensagem += `💰 *Total: R$ ${calcularTotal().toFixed(2)}*\n\n`
    mensagem += `Gostaria de finalizar este pedido!`
    
    const whatsappUrl = `https://wa.me/${configLoja.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(mensagem)}`
    window.open(whatsappUrl, '_blank')
  }

  const precoFinal = (produto) => {
    return produto.precoPromocional || produto.preco
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header da Loja */}
      <div className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Store className="h-6 w-6" />
                {configLoja.nome}
              </h1>
              <p className="text-primary-foreground/80 mt-1">{configLoja.descricao}</p>
            </div>
            <div className="flex items-center gap-4">
              {configLoja.instagram && (
                <a 
                  href={`https://instagram.com/${configLoja.instagram}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-primary-foreground/80"
                >
                  <Instagram className="h-5 w-5" />
                </a>
              )}
              <Button 
                variant="secondary" 
                onClick={() => setIsCarrinhoOpen(true)}
                className="relative"
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                Carrinho
                {carrinho.length > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {carrinho.reduce((total, item) => total + item.quantidade, 0)}
                  </Badge>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Busca */}
      <div className="container mx-auto px-4 py-6">
        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar produtos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Grid de Produtos */}
      <div className="container mx-auto px-4 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {produtosFiltrados.map((produto) => (
            <Card key={produto.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <Badge variant="secondary">{produto.tipo}</Badge>
                  {produto.precoPromocional && (
                    <Badge variant="destructive">Promoção</Badge>
                  )}
                </div>
                <CardTitle className="text-lg line-clamp-2">{produto.nome}</CardTitle>
                <CardDescription>{produto.categoria}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {produto.imagemUrl && (
                  <div className="w-full aspect-square bg-muted rounded-lg flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity"
                       onClick={() => setImagemModal({aberto: true, produto})}>
                    <img 
                      src={produto.imagemUrl} 
                      alt={produto.nome}
                      className="w-full h-full object-cover rounded-lg"
                      onError={(e) => {
                        e.target.style.display = 'none'
                        e.target.nextSibling.style.display = 'flex'
                      }}
                    />
                    <div className="hidden items-center justify-center text-muted-foreground">
                      <Package className="h-8 w-8" />
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <div className="text-center">
                    {produto.precoPromocional ? (
                      <>
                        <div className="text-xl font-bold text-green-600">
                          R$ {produto.precoPromocional.toFixed(2)}
                        </div>
                        <div className="text-sm text-muted-foreground line-through">
                          R$ {produto.preco.toFixed(2)}
                        </div>
                      </>
                    ) : (
                      <div className="text-xl font-bold">
                        R$ {produto.preco.toFixed(2)}
                      </div>
                    )}
                  </div>
                  
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {produto.descricao}
                  </p>
                  
                  <Button 
                    onClick={() => adicionarAoCarrinho(produto)}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar ao Carrinho
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {produtosFiltrados.length === 0 && (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-xl text-muted-foreground">Nenhum produto encontrado</p>
          </div>
        )}
      </div>

      {/* Modal do Carrinho */}
      <Dialog open={isCarrinhoOpen} onOpenChange={setIsCarrinhoOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              Carrinho de Compras
            </DialogTitle>
            <DialogDescription>
              Revise seus produtos antes de enviar o pedido
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {carrinho.length === 0 ? (
              <div className="text-center py-8">
                <ShoppingCart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Seu carrinho está vazio</p>
              </div>
            ) : (
              <>
                {carrinho.map((item) => (
                  <div key={item.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                    {item.imagemUrl && (
                      <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center flex-shrink-0">
                        <img 
                          src={item.imagemUrl} 
                          alt={item.nome}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      </div>
                    )}
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium truncate">{item.nome}</h4>
                      <p className="text-sm text-muted-foreground">{item.categoria}</p>
                      <p className="text-sm font-medium">
                        R$ {precoFinal(item).toFixed(2)} cada
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => alterarQuantidade(item.id, item.quantidade - 1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-8 text-center">{item.quantidade}</span>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => alterarQuantidade(item.id, item.quantidade + 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => removerDoCarrinho(item.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                    
                    <div className="text-right">
                      <p className="font-medium">
                        R$ {(precoFinal(item) * item.quantidade).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
                
                <div className="border-t pt-4">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Total:</span>
                    <span>R$ {calcularTotal().toFixed(2)}</span>
                  </div>
                </div>
                
                <Button 
                  onClick={enviarParaWhatsApp}
                  className="w-full"
                  size="lg"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Enviar Pedido via WhatsApp
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Visualização de Imagem */}
      <Dialog open={imagemModal.aberto} onOpenChange={(aberto) => setImagemModal({aberto, produto: null})}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>{imagemModal.produto?.nome}</DialogTitle>
            <DialogDescription>{imagemModal.produto?.categoria}</DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-center">
            {imagemModal.produto?.imagemUrl && (
              <img 
                src={imagemModal.produto.imagemUrl} 
                alt={imagemModal.produto.nome}
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            )}
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Preço:</span>
              <div className="text-right">
                {imagemModal.produto?.precoPromocional ? (
                  <>
                    <div className="text-lg font-bold text-green-600">
                      R$ {imagemModal.produto.precoPromocional.toFixed(2)}
                    </div>
                    <div className="text-sm text-muted-foreground line-through">
                      R$ {imagemModal.produto.preco.toFixed(2)}
                    </div>
                  </>
                ) : (
                  <div className="text-lg font-bold">
                    R$ {imagemModal.produto?.preco.toFixed(2)}
                  </div>
                )}
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              {imagemModal.produto?.descricao}
            </p>
            <Button 
              onClick={() => {
                adicionarAoCarrinho(imagemModal.produto)
                setImagemModal({aberto: false, produto: null})
              }}
              className="w-full"
            >
              <Plus className="h-4 w-4 mr-2" />
              Adicionar ao Carrinho
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default LojaPublica

