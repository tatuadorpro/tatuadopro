import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Image as ImageIcon,
  Settings,
  Share,
  Eye,
  Clock,
  MapPin,
  DollarSign,
  User
} from 'lucide-react'

const Portfolio = () => {
  const [configPortfolio, setConfigPortfolio] = useState({
    nome: 'Portfólio - ART TATTOO',
    whatsapp: '+5553999621044',
    instagram: 'alex_souza_tattoo',
    descricao: 'Confira os trabalhos realizados pelo estúdio ART TATTOO. Arte, qualidade e profissionalismo em cada tatuagem.',
    ativo: true
  })

  const [trabalhos, setTrabalhos] = useState([
    {
      id: 1,
      titulo: 'Tatuagem Tribal Braço',
      estilo: 'Tribal',
      tamanho: '20x15 cm',
      localCorpo: 'Braço direito',
      duracao: '4 horas',
      clienteId: 1,
      clienteNome: 'João Silva',
      preco: 450.00,
      imagemUrl: '',
      descricao: 'Tatuagem tribal com traços marcantes e sombreamento detalhado'
    },
    {
      id: 2,
      titulo: 'Rosa Realista',
      estilo: 'Realismo',
      tamanho: '15x12 cm',
      localCorpo: 'Antebraço esquerdo',
      duracao: '3 horas',
      clienteId: 2,
      clienteNome: 'Maria Santos',
      preco: 380.00,
      imagemUrl: '',
      descricao: 'Rosa vermelha com técnica realista e sombreamento suave'
    },
    {
      id: 3,
      titulo: 'Mandala Geométrica',
      estilo: 'Geométrico',
      tamanho: '25x25 cm',
      localCorpo: 'Costas',
      duracao: '6 horas',
      clienteId: 3,
      clienteNome: 'Carlos Oliveira',
      preco: 750.00,
      imagemUrl: '',
      descricao: 'Mandala com padrões geométricos complexos e linhas precisas'
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [filterEstilo, setFilterEstilo] = useState('todos')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false)
  const [editingTrabalho, setEditingTrabalho] = useState(null)

  const [novoTrabalho, setNovoTrabalho] = useState({
    titulo: '',
    estilo: '',
    tamanho: '',
    localCorpo: '',
    duracao: '',
    clienteNome: '',
    preco: '',
    imagemUrl: '',
    descricao: ''
  })

  // Estilos disponíveis
  const estilos = [
    'Realismo', 'Tribal', 'Old School', 'New School', 'Geométrico', 
    'Blackwork', 'Aquarela', 'Minimalista', 'Japonês', 'Biomecânico', 'Outros'
  ]

  // Filtros
  const trabalhosFiltrados = trabalhos.filter(trabalho => {
    const matchesSearch = trabalho.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trabalho.clienteNome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trabalho.estilo.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesEstilo = filterEstilo === 'todos' || trabalho.estilo === filterEstilo
    return matchesSearch && matchesEstilo
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (editingTrabalho) {
      setTrabalhos(trabalhos.map(trabalho => 
        trabalho.id === editingTrabalho.id 
          ? { 
              ...novoTrabalho, 
              id: editingTrabalho.id, 
              preco: parseFloat(novoTrabalho.preco),
              clienteId: editingTrabalho.clienteId
            }
          : trabalho
      ))
    } else {
      const trabalho = {
        ...novoTrabalho,
        id: Date.now(),
        preco: parseFloat(novoTrabalho.preco),
        clienteId: null
      }
      setTrabalhos([...trabalhos, trabalho])
    }
    
    setNovoTrabalho({
      titulo: '',
      estilo: '',
      tamanho: '',
      localCorpo: '',
      duracao: '',
      clienteNome: '',
      preco: '',
      imagemUrl: '',
      descricao: ''
    })
    setEditingTrabalho(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (trabalho) => {
    setEditingTrabalho(trabalho)
    setNovoTrabalho({
      ...trabalho,
      preco: trabalho.preco.toString()
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setTrabalhos(trabalhos.filter(trabalho => trabalho.id !== id))
  }

  const gerarLinkPortfolio = async () => {
    // Gerar link do portfólio público
    const portfolioId = configPortfolio.nome.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
    const link = `${window.location.origin}/portfolio-publico/${portfolioId}`
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: configPortfolio.nome,
          text: `Confira meu portfólio de tatuagens: ${configPortfolio.nome}`,
          url: link
        })
      } catch (err) {
        console.log('Erro ao compartilhar:', err)
        navigator.clipboard.writeText(link)
        alert('Link do portfólio copiado para a área de transferência!')
      }
    } else {
      navigator.clipboard.writeText(link)
      alert('Link do portfólio copiado para a área de transferência!')
    }
  }

  // Estatísticas
  const totalTrabalhos = trabalhos.length
  const estiloMaisComum = trabalhos.reduce((acc, trabalho) => {
    acc[trabalho.estilo] = (acc[trabalho.estilo] || 0) + 1
    return acc
  }, {})
  const estiloTop = Object.entries(estiloMaisComum).sort(([,a], [,b]) => b - a)[0]?.[0] || 'N/A'
  const receitaTotal = trabalhos.reduce((sum, trabalho) => sum + trabalho.preco, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Portfólio</h1>
          <p className="text-muted-foreground">Gerencie seus trabalhos e portfólio digital</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Dialog open={isConfigDialogOpen} onOpenChange={setIsConfigDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full sm:w-auto">
                <Settings className="h-4 w-4 mr-2" />
                Configurar Portfólio
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Configurações do Portfólio</DialogTitle>
                <DialogDescription>
                  Configure as informações do seu portfólio digital
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nome-portfolio">Nome do Portfólio</Label>
                  <Input
                    id="nome-portfolio"
                    value={configPortfolio.nome}
                    onChange={(e) => setConfigPortfolio({...configPortfolio, nome: e.target.value})}
                    placeholder="Nome do seu portfólio"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="whatsapp-portfolio">WhatsApp</Label>
                  <Input
                    id="whatsapp-portfolio"
                    value={configPortfolio.whatsapp}
                    onChange={(e) => setConfigPortfolio({...configPortfolio, whatsapp: e.target.value})}
                    placeholder="+55 53 99999-9999"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="instagram-portfolio">Instagram</Label>
                  <Input
                    id="instagram-portfolio"
                    value={configPortfolio.instagram}
                    onChange={(e) => setConfigPortfolio({...configPortfolio, instagram: e.target.value})}
                    placeholder="seu_usuario"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="descricao-portfolio">Descrição</Label>
                  <Textarea
                    id="descricao-portfolio"
                    value={configPortfolio.descricao}
                    onChange={(e) => setConfigPortfolio({...configPortfolio, descricao: e.target.value})}
                    placeholder="Descrição do seu portfólio"
                  />
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsConfigDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={() => setIsConfigDialogOpen(false)}>
                    Salvar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button onClick={gerarLinkPortfolio} className="w-full sm:w-auto">
            <Share className="h-4 w-4 mr-2" />
            Compartilhar Portfólio
          </Button>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Plus className="h-4 w-4 mr-2" />
                Novo Trabalho
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingTrabalho ? 'Editar Trabalho' : 'Novo Trabalho'}</DialogTitle>
                <DialogDescription>
                  Adicione um trabalho ao seu portfólio
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="titulo">Título</Label>
                    <Input
                      id="titulo"
                      value={novoTrabalho.titulo}
                      onChange={(e) => setNovoTrabalho({...novoTrabalho, titulo: e.target.value})}
                      placeholder="Título do trabalho"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="estilo">Estilo</Label>
                    <Select value={novoTrabalho.estilo} onValueChange={(value) => setNovoTrabalho({...novoTrabalho, estilo: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o estilo" />
                      </SelectTrigger>
                      <SelectContent>
                        {estilos.map(estilo => (
                          <SelectItem key={estilo} value={estilo}>{estilo}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tamanho">Tamanho</Label>
                    <Input
                      id="tamanho"
                      value={novoTrabalho.tamanho}
                      onChange={(e) => setNovoTrabalho({...novoTrabalho, tamanho: e.target.value})}
                      placeholder="Ex: 15x10 cm"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="local-corpo">Local do Corpo</Label>
                    <Input
                      id="local-corpo"
                      value={novoTrabalho.localCorpo}
                      onChange={(e) => setNovoTrabalho({...novoTrabalho, localCorpo: e.target.value})}
                      placeholder="Ex: Braço direito"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="duracao">Duração</Label>
                    <Input
                      id="duracao"
                      value={novoTrabalho.duracao}
                      onChange={(e) => setNovoTrabalho({...novoTrabalho, duracao: e.target.value})}
                      placeholder="Ex: 3 horas"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cliente-nome">Cliente</Label>
                    <Input
                      id="cliente-nome"
                      value={novoTrabalho.clienteNome}
                      onChange={(e) => setNovoTrabalho({...novoTrabalho, clienteNome: e.target.value})}
                      placeholder="Nome do cliente (opcional)"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="preco-trabalho">Preço (R$)</Label>
                    <Input
                      id="preco-trabalho"
                      type="number"
                      step="0.01"
                      value={novoTrabalho.preco}
                      onChange={(e) => setNovoTrabalho({...novoTrabalho, preco: e.target.value})}
                      placeholder="0,00"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="imagem-trabalho">Imagem do Trabalho</Label>
                    <div className="space-y-2">
                      <Input
                        id="imagem-trabalho"
                        value={novoTrabalho.imagemUrl}
                        onChange={(e) => setNovoTrabalho({...novoTrabalho, imagemUrl: e.target.value})}
                        placeholder="https://exemplo.com/imagem.jpg"
                      />
                      <div className="flex gap-2">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (e) => {
                                setNovoTrabalho({...novoTrabalho, imagemUrl: e.target.result});
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                          className="hidden"
                          id="upload-trabalho-image"
                        />
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => document.getElementById('upload-trabalho-image').click()}
                          className="flex-1"
                        >
                          Escolher da Galeria
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => {
                            // Funcionalidade para buscar imagem externa (pode ser implementada com uma API de busca de imagens)
                            const url = prompt('Digite a URL da imagem:');
                            if (url) {
                              setNovoTrabalho({...novoTrabalho, imagemUrl: url});
                            }
                          }}
                          className="flex-1"
                        >
                          Buscar Online
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="descricao-trabalho">Descrição</Label>
                  <Textarea
                    id="descricao-trabalho"
                    value={novoTrabalho.descricao}
                    onChange={(e) => setNovoTrabalho({...novoTrabalho, descricao: e.target.value})}
                    placeholder="Descrição do trabalho realizado"
                    rows={4}
                  />
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    {editingTrabalho ? 'Atualizar' : 'Salvar'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Trabalhos</CardTitle>
            <ImageIcon className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTrabalhos}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estilo Mais Comum</CardTitle>
            <Eye className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{estiloTop}</div>
            <div className="text-sm text-muted-foreground">
              {estiloMaisComum[estiloTop] || 0} trabalhos
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {receitaTotal.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Preço Médio</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              R$ {totalTrabalhos > 0 ? (receitaTotal / totalTrabalhos).toFixed(2) : '0,00'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle>Galeria de Trabalhos</CardTitle>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar trabalhos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterEstilo} onValueChange={setFilterEstilo}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrar por estilo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os estilos</SelectItem>
                {estilos.map(estilo => (
                  <SelectItem key={estilo} value={estilo}>{estilo}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trabalhosFiltrados.map((trabalho) => (
              <Card key={trabalho.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">{trabalho.estilo}</Badge>
                    <div className="flex space-x-1">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(trabalho)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(trabalho.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{trabalho.titulo}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {trabalho.imagemUrl && (
                    <div className="w-full h-48 bg-muted rounded-lg overflow-hidden">
                      <img 
                        src={trabalho.imagemUrl} 
                        alt={trabalho.titulo}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.style.display = 'none'
                          e.target.nextSibling.style.display = 'flex'
                        }}
                      />
                      <div className="hidden w-full h-full items-center justify-center text-muted-foreground">
                        <ImageIcon className="h-12 w-12" />
                      </div>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    {trabalho.tamanho && (
                      <div className="flex items-center space-x-2 text-sm">
                        <span className="text-muted-foreground">Tamanho:</span>
                        <span>{trabalho.tamanho}</span>
                      </div>
                    )}
                    
                    {trabalho.localCorpo && (
                      <div className="flex items-center space-x-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{trabalho.localCorpo}</span>
                      </div>
                    )}
                    
                    {trabalho.duracao && (
                      <div className="flex items-center space-x-2 text-sm">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{trabalho.duracao}</span>
                      </div>
                    )}
                    
                    {trabalho.clienteNome && (
                      <div className="flex items-center space-x-2 text-sm">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span>{trabalho.clienteNome}</span>
                      </div>
                    )}
                    
                    {trabalho.preco > 0 && (
                      <div className="flex items-center space-x-2 text-sm">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        <span className="font-semibold text-gain">
                          R$ {trabalho.preco.toLocaleString('pt-BR')}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {trabalho.descricao && (
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {trabalho.descricao}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
          
          {trabalhosFiltrados.length === 0 && (
            <div className="text-center py-8">
              <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhum trabalho encontrado</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default Portfolio

