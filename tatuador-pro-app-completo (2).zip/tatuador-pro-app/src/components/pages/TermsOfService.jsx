import React from 'react';

const TermsOfService = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Termos de Uso</h1>
      <p className="mb-2">Bem-vindo ao Tatuador PRO! Ao acessar e utilizar este aplicativo, você concorda em cumprir e estar vinculado aos seguintes termos e condições de uso. Por favor, leia-os atentamente.</p>

      <h2 className="text-xl font-semibold mb-2">1. Aceitação dos Termos</h2>
      <p className="mb-2">Ao utilizar o Tatuador PRO, você reconhece que leu, entendeu e concorda com estes Termos de Uso, bem como com nossa Política de Privacidade. Se você não concorda com qualquer parte destes termos, não utilize o aplicativo.</p>

      <h2 className="text-xl font-semibold mb-2">2. Uso do Aplicativo</h2>
      <p className="mb-2">O Tatuador PRO é destinado a profissionais da tatuagem para auxiliar na gestão de seus negócios, incluindo controle financeiro, agendamento de clientes, gestão de estoque e portfólio. Você concorda em usar o aplicativo apenas para fins lícitos e de acordo com estes Termos de Uso.</p>

      <h2 className="text-xl font-semibold mb-2">3. Dados do Usuário</h2>
      <p className="mb-2">Todas as informações e dados inseridos por você no aplicativo (como dados de clientes, ganhos, gastos, etc.) são armazenados localmente no seu dispositivo. O Tatuador PRO não coleta, armazena ou transmite seus dados para servidores externos. A responsabilidade pela segurança e backup de seus dados é exclusivamente sua.</p>

      <h2 className="text-xl font-semibold mb-2">4. Propriedade Intelectual</h2>
      <p className="mb-2">Todo o conteúdo e funcionalidades do Tatuador PRO, incluindo, mas não se limitando a, texto, gráficos, logotipos, ícones, imagens, clipes de áudio, downloads digitais, compilações de dados e software, são propriedade do desenvolvedor do aplicativo e protegidos por leis de direitos autorais.</p>

      <h2 className="text-xl font-semibold mb-2">5. Limitação de Responsabilidade</h2>
      <p className="mb-2">O Tatuador PRO é fornecido "como está", sem garantias de qualquer tipo, expressas ou implícitas. Não garantimos que o aplicativo será ininterrupto, livre de erros ou que os dados estarão sempre seguros. Em nenhuma circunstância o desenvolvedor será responsável por quaisquer danos diretos, indiretos, incidentais, especiais ou consequenciais resultantes do uso ou da incapacidade de usar o aplicativo.</p>

      <h2 className="text-xl font-semibold mb-2">6. Alterações nos Termos de Uso</h2>
      <p className="mb-2">Reservamo-nos o direito de modificar estes Termos de Uso a qualquer momento. Quaisquer alterações serão publicadas nesta página. Seu uso continuado do aplicativo após a publicação de alterações constitui sua aceitação dos novos termos.</p>

      <h2 className="text-xl font-semibold mb-2">7. Contato</h2>
      <p className="mb-2">Se você tiver alguma dúvida sobre estes Termos de Uso, entre em contato conosco através dos canais de suporte do aplicativo.</p>
    </div>
  );
};

export default TermsOfService;


