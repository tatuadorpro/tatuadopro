import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight,
  Edit, 
  Trash2,
  Clock,
  DollarSign,
  TrendingUp,
  TrendingDown
} from 'lucide-react'

const Agenda = () => {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [eventos, setEventos] = useState([
    {
      id: 1,
      tipo: 'ganho',
      titulo: 'Tatuagem - João Silva',
      data: '2024-01-25',
      hora: '14:00',
      valor: 450.00,
      cliente: 'João Silva',
      descricao: 'Tatuagem tribal no braço',
      status: 'agendado'
    },
    {
      id: 2,
      tipo: 'gasto',
      titulo: 'Compra de Tintas',
      data: '2024-01-26',
      hora: '10:00',
      valor: 320.00,
      descricao: 'Reposição de estoque de tintas',
      status: 'pendente'
    },
    {
      id: 3,
      tipo: 'ganho',
      titulo: 'Curso Básico - Maria Santos',
      data: '2024-01-28',
      hora: '09:00',
      valor: 800.00,
      cliente: 'Maria Santos',
      descricao: 'Curso básico de tatuagem',
      status: 'confirmado'
    }
  ])

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingEvento, setEditingEvento] = useState(null)

  const [novoEvento, setNovoEvento] = useState({
    tipo: '',
    titulo: '',
    data: '',
    hora: '',
    valor: '',
    cliente: '',
    descricao: '',
    status: 'agendado'
  })

  // Funções de navegação do calendário
  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
  }

  const currentMonth = () => {
    setCurrentDate(new Date())
  }

  // Gerar dias do calendário
  const generateCalendarDays = () => {
    const year = currentDate.getFullYear()
    const month = currentDate.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const startDate = new Date(firstDay)
    startDate.setDate(startDate.getDate() - firstDay.getDay())

    const days = []
    const currentDateObj = new Date(startDate)

    for (let i = 0; i < 42; i++) {
      const dayEvents = eventos.filter(evento => 
        evento.data === currentDateObj.toISOString().split('T')[0]
      )
      
      days.push({
        date: new Date(currentDateObj),
        isCurrentMonth: currentDateObj.getMonth() === month,
        isToday: currentDateObj.toDateString() === new Date().toDateString(),
        events: dayEvents
      })
      
      currentDateObj.setDate(currentDateObj.getDate() + 1)
    }

    return days
  }

  const calendarDays = generateCalendarDays()
  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ]

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (editingEvento) {
      setEventos(eventos.map(evento => 
        evento.id === editingEvento.id 
          ? { ...novoEvento, id: editingEvento.id, valor: parseFloat(novoEvento.valor) }
          : evento
      ))
    } else {
      const evento = {
        ...novoEvento,
        id: Date.now(),
        valor: parseFloat(novoEvento.valor)
      }
      setEventos([...eventos, evento])
    }
    
    setNovoEvento({
      tipo: '',
      titulo: '',
      data: '',
      hora: '',
      valor: '',
      cliente: '',
      descricao: '',
      status: 'agendado'
    })
    setEditingEvento(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (evento) => {
    setEditingEvento(evento)
    setNovoEvento({
      ...evento,
      valor: evento.valor.toString()
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setEventos(eventos.filter(evento => evento.id !== id))
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmado': return 'bg-gain'
      case 'agendado': return 'bg-pending'
      case 'pendente': return 'bg-low-stock'
      case 'cancelado': return 'bg-expense'
      default: return 'bg-muted'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Agenda</h1>
          <p className="text-muted-foreground">Gerencie seus agendamentos e eventos</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0">
              <Plus className="h-4 w-4 mr-2" />
              Novo Evento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingEvento ? 'Editar Evento' : 'Novo Evento'}</DialogTitle>
              <DialogDescription>
                Preencha as informações do evento
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="tipo">Tipo de Evento</Label>
                <Select value={novoEvento.tipo} onValueChange={(value) => setNovoEvento({...novoEvento, tipo: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ganho">Ganho</SelectItem>
                    <SelectItem value="gasto">Gasto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="titulo">Título</Label>
                <Input
                  id="titulo"
                  value={novoEvento.titulo}
                  onChange={(e) => setNovoEvento({...novoEvento, titulo: e.target.value})}
                  placeholder="Título do evento"
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="data">Data</Label>
                  <Input
                    id="data"
                    type="date"
                    value={novoEvento.data}
                    onChange={(e) => setNovoEvento({...novoEvento, data: e.target.value})}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="hora">Hora</Label>
                  <Input
                    id="hora"
                    type="time"
                    value={novoEvento.hora}
                    onChange={(e) => setNovoEvento({...novoEvento, hora: e.target.value})}
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="valor">Valor (R$)</Label>
                <Input
                  id="valor"
                  type="number"
                  step="0.01"
                  value={novoEvento.valor}
                  onChange={(e) => setNovoEvento({...novoEvento, valor: e.target.value})}
                  placeholder="0,00"
                />
              </div>
              
              {novoEvento.tipo === 'ganho' && (
                <div className="space-y-2">
                  <Label htmlFor="cliente">Cliente</Label>
                  <Input
                    id="cliente"
                    value={novoEvento.cliente}
                    onChange={(e) => setNovoEvento({...novoEvento, cliente: e.target.value})}
                    placeholder="Nome do cliente"
                  />
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={novoEvento.status} onValueChange={(value) => setNovoEvento({...novoEvento, status: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="agendado">Agendado</SelectItem>
                    <SelectItem value="confirmado">Confirmado</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="cancelado">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  id="descricao"
                  value={novoEvento.descricao}
                  onChange={(e) => setNovoEvento({...novoEvento, descricao: e.target.value})}
                  placeholder="Descrição do evento"
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingEvento ? 'Atualizar' : 'Salvar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Navegação do Calendário */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={previousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <div className="text-center">
              <h2 className="text-xl font-semibold">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" onClick={currentMonth}>
                Hoje
              </Button>
              <Button variant="outline" onClick={nextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Cabeçalho dos dias da semana */}
          <div className="grid grid-cols-7 gap-1 mb-4">
            {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
              <div key={day} className="p-2 text-center font-medium text-muted-foreground">
                {day}
              </div>
            ))}
          </div>
          
          {/* Dias do calendário */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, index) => (
              <div
                key={index}
                className={`min-h-[100px] p-2 border rounded-lg ${
                  day.isCurrentMonth ? 'bg-card' : 'bg-muted/50'
                } ${day.isToday ? 'ring-2 ring-primary' : ''}`}
              >
                <div className={`text-sm font-medium mb-1 ${
                  day.isCurrentMonth ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  {day.date.getDate()}
                </div>
                
                <div className="space-y-1">
                  {day.events.map(evento => (
                    <div
                      key={evento.id}
                      className={`text-xs p-1 rounded text-white cursor-pointer ${
                        evento.tipo === 'ganho' ? 'bg-gain' : 'bg-expense'
                      }`}
                      onClick={() => handleEdit(evento)}
                    >
                      <div className="font-medium truncate">{evento.titulo}</div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>{evento.hora}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Lista de Eventos do Mês */}
      <Card>
        <CardHeader>
          <CardTitle>Eventos do Mês</CardTitle>
          <CardDescription>
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {eventos
              .filter(evento => {
                const eventoDate = new Date(evento.data)
                return eventoDate.getMonth() === currentDate.getMonth() && 
                       eventoDate.getFullYear() === currentDate.getFullYear()
              })
              .sort((a, b) => new Date(a.data + ' ' + a.hora) - new Date(b.data + ' ' + b.hora))
              .map((evento) => (
                <div key={evento.id} className="border rounded-lg p-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        {evento.tipo === 'ganho' ? (
                          <TrendingUp className="h-4 w-4 text-gain" />
                        ) : (
                          <TrendingDown className="h-4 w-4 text-expense" />
                        )}
                        <Badge className={getStatusColor(evento.status)}>
                          {evento.status}
                        </Badge>
                      </div>
                      <h3 className="font-semibold">{evento.titulo}</h3>
                      <p className="text-sm text-muted-foreground">{evento.descricao}</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <CalendarIcon className="h-4 w-4" />
                          <span>{evento.data}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{evento.hora}</span>
                        </div>
                        {evento.cliente && (
                          <span>Cliente: {evento.cliente}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col md:items-end mt-4 md:mt-0">
                      <div className={`text-lg font-bold ${
                        evento.tipo === 'ganho' ? 'text-gain' : 'text-expense'
                      }`}>
                        {evento.tipo === 'ganho' ? '+' : '-'}R$ {evento.valor.toLocaleString('pt-BR')}
                      </div>
                      <div className="flex space-x-2 mt-2">
                        <Button size="sm" variant="outline" onClick={() => handleEdit(evento)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleDelete(evento.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Agenda

