import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Heart, 
  Share2, 
  MessageCircle, 
  Instagram, 
  Phone,
  MapPin,
  Clock,
  DollarSign,
  User,
  Image as ImageIcon,
  ExternalLink
} from 'lucide-react'

const PortfolioPublico = () => {
  const { portfolioId } = useParams()
  
  // Dados do portfólio (normalmente viriam de uma API)
  const [configPortfolio] = useState({
    nome: 'Portfólio - ART TATTOO',
    whatsapp: '+5553999621044',
    instagram: 'alex_souza_tattoo',
    descricao: 'Confira os trabalhos realizados pelo estúdio ART TATTOO. Arte, qualidade e profissionalismo em cada tatuagem.',
    ativo: true
  })

  const [trabalhos] = useState([
    {
      id: 1,
      titulo: 'Tatuagem Tribal Braço',
      estilo: 'Tribal',
      tamanho: '20x15 cm',
      localCorpo: 'Braço direito',
      duracao: '4 horas',
      clienteNome: 'João Silva',
      preco: 450.00,
      imagemUrl: '',
      descricao: 'Tatuagem tribal com traços marcantes e sombreamento detalhado',
      curtidas: 15,
      curtidoPorMim: false
    },
    {
      id: 2,
      titulo: 'Rosa Realista',
      estilo: 'Realismo',
      tamanho: '15x12 cm',
      localCorpo: 'Antebraço esquerdo',
      duracao: '3 horas',
      clienteNome: 'Maria Santos',
      preco: 380.00,
      imagemUrl: '',
      descricao: 'Rosa vermelha com técnica realista e sombreamento suave',
      curtidas: 23,
      curtidoPorMim: false
    },
    {
      id: 3,
      titulo: 'Mandala Geométrica',
      estilo: 'Geométrico',
      tamanho: '25x25 cm',
      localCorpo: 'Costas',
      duracao: '6 horas',
      clienteNome: 'Carlos Oliveira',
      preco: 750.00,
      imagemUrl: '',
      descricao: 'Mandala com padrões geométricos complexos e linhas precisas',
      curtidas: 31,
      curtidoPorMim: false
    }
  ])

  const [trabalhosComCurtidas, setTrabalhosComCurtidas] = useState(trabalhos)

  useEffect(() => {
    // Carregar curtidas do localStorage
    const curtidasSalvas = localStorage.getItem('curtidas_portfolio')
    if (curtidasSalvas) {
      const curtidas = JSON.parse(curtidasSalvas)
      setTrabalhosComCurtidas(trabalhos.map(trabalho => ({
        ...trabalho,
        curtidoPorMim: curtidas.includes(trabalho.id)
      })))
    }
  }, [])

  const handleCurtir = (trabalhoId) => {
    setTrabalhosComCurtidas(prev => {
      const novosTrabalhos = prev.map(trabalho => {
        if (trabalho.id === trabalhoId) {
          const jaCurtido = trabalho.curtidoPorMim
          return {
            ...trabalho,
            curtidas: jaCurtido ? trabalho.curtidas - 1 : trabalho.curtidas + 1,
            curtidoPorMim: !jaCurtido
          }
        }
        return trabalho
      })

      // Salvar curtidas no localStorage
      const curtidas = novosTrabalhos
        .filter(t => t.curtidoPorMim)
        .map(t => t.id)
      localStorage.setItem('curtidas_portfolio', JSON.stringify(curtidas))

      return novosTrabalhos
    })
  }

  const handleCompartilhar = async (trabalho) => {
    const url = `${window.location.origin}/portfolio-publico/${portfolioId}#trabalho-${trabalho.id}`
    const texto = `Confira este trabalho incrível: ${trabalho.titulo} - ${configPortfolio.nome}`
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: trabalho.titulo,
          text: texto,
          url: url
        })
      } catch (err) {
        console.log('Erro ao compartilhar:', err)
        copiarLink(url)
      }
    } else {
      copiarLink(url)
    }
  }

  const copiarLink = (url) => {
    navigator.clipboard.writeText(url).then(() => {
      alert('Link copiado para a área de transferência!')
    })
  }

  const abrirWhatsApp = () => {
    const numero = configPortfolio.whatsapp.replace(/\D/g, '')
    const mensagem = encodeURIComponent(`Olá! Vi seu portfólio e gostaria de agendar uma tatuagem.`)
    window.open(`https://wa.me/${numero}?text=${mensagem}`, '_blank')
  }

  const abrirInstagram = () => {
    window.open(`https://instagram.com/${configPortfolio.instagram}`, '_blank')
  }

  const compartilharPortfolio = async () => {
    const url = window.location.href
    const texto = `Confira o portfólio de ${configPortfolio.nome}`
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: configPortfolio.nome,
          text: texto,
          url: url
        })
      } catch (err) {
        console.log('Erro ao compartilhar:', err)
        copiarLink(url)
      }
    } else {
      copiarLink(url)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold">{configPortfolio.nome}</h1>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              {configPortfolio.descricao}
            </p>
            
            {/* Botões de contato */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                onClick={abrirWhatsApp}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Phone className="h-4 w-4 mr-2" />
                WhatsApp
              </Button>
              
              <Button 
                onClick={abrirInstagram}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
              >
                <Instagram className="h-4 w-4 mr-2" />
                Instagram
              </Button>
              
              <Button 
                onClick={compartilharPortfolio}
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Compartilhar
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Galeria de Trabalhos */}
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Galeria de Trabalhos</h2>
          <p className="text-muted-foreground">
            Confira alguns dos nossos trabalhos mais recentes
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trabalhosComCurtidas.map((trabalho) => (
            <Card 
              key={trabalho.id} 
              className="hover:shadow-lg transition-all duration-300 hover:scale-105"
              id={`trabalho-${trabalho.id}`}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Badge variant="secondary">{trabalho.estilo}</Badge>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleCurtir(trabalho.id)}
                      className={`${trabalho.curtidoPorMim ? 'text-red-500' : 'text-muted-foreground'} hover:text-red-500`}
                    >
                      <Heart 
                        className={`h-4 w-4 mr-1 ${trabalho.curtidoPorMim ? 'fill-current' : ''}`} 
                      />
                      {trabalho.curtidas}
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleCompartilhar(trabalho)}
                      className="text-muted-foreground hover:text-primary"
                    >
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <CardTitle className="text-lg">{trabalho.titulo}</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-3">
                {trabalho.imagemUrl ? (
                  <div className="w-full h-48 bg-muted rounded-lg overflow-hidden">
                    <img 
                      src={trabalho.imagemUrl} 
                      alt={trabalho.titulo}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.style.display = 'none'
                        e.target.nextSibling.style.display = 'flex'
                      }}
                    />
                    <div className="hidden w-full h-full items-center justify-center text-muted-foreground">
                      <ImageIcon className="h-12 w-12" />
                    </div>
                  </div>
                ) : (
                  <div className="w-full h-48 bg-muted rounded-lg flex items-center justify-center">
                    <ImageIcon className="h-12 w-12 text-muted-foreground" />
                  </div>
                )}
                
                <div className="space-y-2">
                  {trabalho.tamanho && (
                    <div className="flex items-center space-x-2 text-sm">
                      <span className="text-muted-foreground">Tamanho:</span>
                      <span>{trabalho.tamanho}</span>
                    </div>
                  )}
                  
                  {trabalho.localCorpo && (
                    <div className="flex items-center space-x-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{trabalho.localCorpo}</span>
                    </div>
                  )}
                  
                  {trabalho.duracao && (
                    <div className="flex items-center space-x-2 text-sm">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{trabalho.duracao}</span>
                    </div>
                  )}
                  
                  {trabalho.clienteNome && (
                    <div className="flex items-center space-x-2 text-sm">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{trabalho.clienteNome}</span>
                    </div>
                  )}
                </div>
                
                {trabalho.descricao && (
                  <p className="text-sm text-muted-foreground">
                    {trabalho.descricao}
                  </p>
                )}
                
                {/* Botão de contato para orçamento */}
                <Button 
                  onClick={abrirWhatsApp}
                  className="w-full mt-4 bg-green-600 hover:bg-green-700"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Solicitar Orçamento
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {trabalhosComCurtidas.length === 0 && (
          <div className="text-center py-12">
            <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Nenhum trabalho encontrado</h3>
            <p className="text-muted-foreground">
              Este portfólio ainda não possui trabalhos cadastrados.
            </p>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-muted mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-semibold">{configPortfolio.nome}</h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              Entre em contato conosco para agendar sua próxima tatuagem ou tirar suas dúvidas.
            </p>
            
            <div className="flex justify-center space-x-4">
              <Button 
                onClick={abrirWhatsApp}
                variant="outline"
                size="sm"
              >
                <Phone className="h-4 w-4 mr-2" />
                {configPortfolio.whatsapp}
              </Button>
              
              <Button 
                onClick={abrirInstagram}
                variant="outline"
                size="sm"
              >
                <Instagram className="h-4 w-4 mr-2" />
                @{configPortfolio.instagram}
              </Button>
            </div>
            
            <div className="pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground">
                © 2024 {configPortfolio.nome}. Todos os direitos reservados.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default PortfolioPublico

