import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Users,
  DollarSign,
  Crown,
  Phone,
  Mail,
  Instagram,
  MapPin
} from 'lucide-react'
import FichaAnamnese from '@/components/FichaAnamnese'

const Clientes = () => {
  const [clientes, setClientes] = useState([
    {
      id: 1,
      nome: 'João Silva',
      celular: '(11) 99999-9999',
      instagram: 'joao_silva',
      email: 'joao@email.com',
      endereco: 'Rua das Flores, 123 - São Paulo, SP',
      fichaAnamnese: {
        historicoSaude: [],
        saudeObservacoes: 'Não possui alergias. Primeira tatuagem.',
        historicoTatuagem: [],
        tatuagemObservacoes: '',
        expectativasCuidados: ''
      },
      observacoes: 'Cliente pontual e educado.',
      receitaTotal: 1250.00
    },
    {
      id: 2,
      nome: 'Maria Santos',
      celular: '(11) 88888-8888',
      instagram: 'maria_santos',
      email: 'maria@email.com',
      endereco: 'Av. Paulista, 456 - São Paulo, SP',
      fichaAnamnese: {
        historicoSaude: ['alergias'],
        saudeObservacoes: 'Alergia a níquel.',
        historicoTatuagem: ['tatuagensAnteriores'],
        tatuagemObservacoes: 'Já possui 3 tatuagens.',
        expectativasCuidados: ''
      },
      observacoes: 'Prefere sessões pela manhã.',
      receitaTotal: 2100.00
    },
    {
      id: 3,
      nome: 'Carlos Oliveira',
      celular: '(11) 77777-7777',
      instagram: 'carlos_oliveira',
      email: 'carlos@email.com',
      endereco: 'Rua Augusta, 789 - São Paulo, SP',
      fichaAnamnese: {
        historicoSaude: [],
        saudeObservacoes: 'Sem restrições médicas.',
        historicoTatuagem: [],
        tatuagemObservacoes: '',
        expectativasCuidados: 'Interessado em tatuagens grandes.'
      },
      observacoes: 'Interessado em tatuagens grandes.',
      receitaTotal: 850.00
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingCliente, setEditingCliente] = useState(null)

  const [novoCliente, setNovoCliente] = useState({
    nome: '',
    celular: '',
    instagram: '',
    email: '',
    endereco: '',
    fichaAnamnese: {
      historicoSaude: [],
      saudeObservacoes: '',
      historicoTatuagem: [],
      tatuagemObservacoes: '',
      expectativasCuidados: ''
    },
    observacoes: ''
  })

  // Cálculos
  const totalClientes = clientes.length
  const receitaTotal = clientes.reduce((sum, cliente) => sum + cliente.receitaTotal, 0)
  const clienteTop = clientes.reduce((prev, current) => 
    (prev.receitaTotal > current.receitaTotal) ? prev : current
  )

  // Filtros
  const clientesFiltrados = clientes.filter(cliente =>
    cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cliente.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cliente.celular.includes(searchTerm)
  )

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (editingCliente) {
      setClientes(clientes.map(cliente => 
        cliente.id === editingCliente.id 
          ? { ...novoCliente, id: editingCliente.id, receitaTotal: editingCliente.receitaTotal }
          : cliente
      ))
    } else {
      const cliente = {
        ...novoCliente,
        id: Date.now(),
        receitaTotal: 0
      }
      setClientes([...clientes, cliente])
    }
    
    setNovoCliente({
      nome: "",
      celular: "",
      instagram: "",
      email: "",
      endereco: "",
      fichaAnamnese: {
        historicoSaude: [],
        saudeObservacoes: "",
        historicoTatuagem: [],
        tatuagemObservacoes: "",
        expectativasCuidados: ""
      },
      observacoes: ""
    })
    setEditingCliente(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (cliente) => {
    setEditingCliente(cliente)
    setNovoCliente({
      nome: cliente.nome,
      celular: cliente.celular,
      instagram: cliente.instagram,
      email: cliente.email,
      endereco: cliente.endereco,
      fichaAnamnese: cliente.fichaAnamnese || {
        historicoSaude: [],
        saudeObservacoes: "",
        historicoTatuagem: [],
        tatuagemObservacoes: "",
        expectativasCuidados: ""
      },
      observacoes: cliente.observacoes
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setClientes(clientes.filter(cliente => cliente.id !== id))
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Clientes</h1>
          <p className="text-muted-foreground">Gerencie sua base de clientes</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0">
              <Plus className="h-4 w-4 mr-2" />
              Novo Cliente
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingCliente ? 'Editar Cliente' : 'Novo Cliente'}</DialogTitle>
              <DialogDescription>
                Preencha as informações do cliente
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome Completo</Label>
                  <Input
                    id="nome"
                    value={novoCliente.nome}
                    onChange={(e) => setNovoCliente({...novoCliente, nome: e.target.value})}
                    placeholder="Nome completo do cliente"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="celular">Celular</Label>
                  <Input
                    id="celular"
                    value={novoCliente.celular}
                    onChange={(e) => setNovoCliente({...novoCliente, celular: e.target.value})}
                    placeholder="(00) 00000-0000"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="instagram">Instagram</Label>
                  <Input
                    id="instagram"
                    value={novoCliente.instagram}
                    onChange={(e) => setNovoCliente({...novoCliente, instagram: e.target.value})}
                    placeholder="@usuario"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={novoCliente.email}
                    onChange={(e) => setNovoCliente({...novoCliente, email: e.target.value})}
                    placeholder="cliente@email.com"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="endereco">Endereço</Label>
                <Input
                  id="endereco"
                  value={novoCliente.endereco}
                  onChange={(e) => setNovoCliente({...novoCliente, endereco: e.target.value})}
                  placeholder="Endereço completo"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fichaAnamnese">Ficha de Anamnese</Label>
                <FichaAnamnese 
                  anamneseData={novoCliente.fichaAnamnese}
                  setAnamneseData={(updater) => {
                    setNovoCliente(prevNovoCliente => ({
                      ...prevNovoCliente,
                      fichaAnamnese: typeof updater === 'function'
                        ? updater(prevNovoCliente.fichaAnamnese)
                        : updater
                    }));
                  }}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  value={novoCliente.observacoes}
                  onChange={(e) => setNovoCliente({...novoCliente, observacoes: e.target.value})}
                  placeholder="Observações adicionais sobre o cliente"
                  rows={3}
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingCliente ? 'Atualizar' : 'Salvar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalClientes}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cliente Top</CardTitle>
            <Crown className="h-4 w-4 text-pending" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">
              {clienteTop.nome}
            </div>
            <div className="text-sm text-muted-foreground">
              R$ {clienteTop.receitaTotal.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {receitaTotal.toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Busca */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Clientes</CardTitle>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome, email ou telefone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {clientesFiltrados.map((cliente) => (
              <Card key={cliente.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{cliente.nome}</CardTitle>
                    <div className="flex space-x-1">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(cliente)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(cliente.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="text-sm text-gain font-semibold">
                    Receita: R$ {cliente.receitaTotal.toLocaleString('pt-BR')}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {cliente.celular && (
                    <div className="flex items-center space-x-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{cliente.celular}</span>
                    </div>
                  )}
                  
                  {cliente.email && (
                    <div className="flex items-center space-x-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span className="truncate">{cliente.email}</span>
                    </div>
                  )}
                  
                  {cliente.instagram && (
                    <div className="flex items-center space-x-2 text-sm">
                      <Instagram className="h-4 w-4 text-muted-foreground" />
                      <span>@{cliente.instagram}</span>
                    </div>
                  )}
                  
                  {cliente.endereco && (
                    <div className="flex items-start space-x-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <span className="text-xs">{cliente.endereco}</span>
                    </div>
                  )}
                  
                  {cliente.fichaAnamnese && (
                    <div className="mt-3">
                      <Badge variant="secondary" className="text-xs">
                        Anamnese
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {Object.entries(cliente.fichaAnamnese).map(([key, value]) => {
                          if (Array.isArray(value) && value.length > 0) {
                            return `${key}: ${value.join(", ")}`;
                          } else if (typeof value === "string" && value.length > 0) {
                            return `${key}: ${value}`;
                          }
                          return null;
                        }).filter(Boolean).join("; ")}
                      </p>
                    </div>
                  )}
                  
                  {cliente.observacoes && (
                    <div className="mt-3">
                      <Badge variant="outline" className="text-xs">
                        Observações
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {cliente.observacoes}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
          
          {clientesFiltrados.length === 0 && (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhum cliente encontrado</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default Clientes

