import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Política de Privacidade</h1>
      <p className="mb-2">Esta Política de Privacidade descreve como suas informações pessoais são coletadas, usadas e compartilhadas quando você utiliza o aplicativo Tatuador PRO.</p>

      <h2 className="text-xl font-semibold mb-2">Coleta de Informações Pessoais</h2>
      <p className="mb-2">Não coletamos nenhuma informação pessoal identificável diretamente através do aplicativo. Todas as informações inseridas no aplicativo (como dados de clientes, ganhos, gastos, etc.) são armazenadas localmente no seu dispositivo e não são transmitidas para nenhum servidor externo.</p>

      <h2 className="text-xl font-semibold mb-2">Uso de Informações</h2>
      <p className="mb-2">As informações que você insere no aplicativo são usadas exclusivamente para os fins de gerenciamento do seu negócio de tatuagem, como controle financeiro, agendamento e gestão de estoque. Não utilizamos suas informações para marketing, publicidade ou qualquer outro propósito externo.</p>

      <h2 className="text-xl font-semibold mb-2">Compartilhamento de Informações Pessoais</h2>
      <p className="mb-2">Não compartilhamos suas informações pessoais com terceiros. Como os dados são armazenados localmente, não há transmissão ou acesso por parte de entidades externas.</p>

      <h2 className="text-xl font-semibold mb-2">Segurança dos Dados</h2>
      <p className="mb-2">Tomamos precauções razoáveis para proteger as informações armazenadas no seu dispositivo contra acesso não autorizado, alteração, divulgação ou destruição. No entanto, lembre-se que nenhum método de transmissão pela internet ou método de armazenamento eletrônico é 100% seguro.</p>

      <h2 className="text-xl font-semibold mb-2">Alterações nesta Política de Privacidade</h2>
      <p className="mb-2">Podemos atualizar nossa Política de Privacidade de tempos em tempos. Aconselhamos que você revise esta página periodicamente para quaisquer alterações. As alterações a esta Política de Privacidade são efetivas quando são publicadas nesta página.</p>

      <h2 className="text-xl font-semibold mb-2">Contato</h2>
      <p className="mb-2">Se você tiver alguma dúvida sobre esta Política de Privacidade, entre em contato conosco através dos canais de suporte do aplicativo.</p>
    </div>
  );
};

export default PrivacyPolicy;


