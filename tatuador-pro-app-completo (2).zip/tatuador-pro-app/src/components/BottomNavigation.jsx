import { Link, useLocation } from 'react-router-dom'
import {
  LayoutDashboard,
  TrendingUp,
  Users,
  Calendar,
  TrendingDown,
  Store,
  Image,
  Package,
  Calculator,
  BarChart3,
  FileText,
  Info
} from 'lucide-react'

const BottomNavigation = () => {
  const location = useLocation()

  // Consolidar todos os itens em um único array
  const allItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/ganhos', icon: TrendingUp, label: 'Ganhos' },
    { path: '/clientes', icon: Users, label: 'Clientes' },
    { path: '/agenda', icon: Calendar, label: 'Agenda' },
    { path: '/gastos', icon: TrendingDown, label: 'Gastos' },
    { path: '/loja', icon: Store, label: 'Loja' },
    { path: '/portfolio', icon: Image, label: 'Portfólio' },
    { path: '/estoque', icon: Package, label: 'Estoque' },
    { path: '/calculadora', icon: Calculator, label: 'Calculadora' },
    { path: '/relatorios', icon: BarChart3, label: 'Relatórios' },

  ]

  const isActive = (path) => location.pathname === path

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
      {/* Scrollable Navigation Container */}
      <div className="relative">
        {/* Gradient overlays para indicar scroll */}
        <div className="absolute left-0 top-0 bottom-0 w-4 bg-gradient-to-r from-card to-transparent z-10 pointer-events-none"></div>
        <div className="absolute right-0 top-0 bottom-0 w-4 bg-gradient-to-l from-card to-transparent z-10 pointer-events-none"></div>
        
        {/* Scrollable container */}
        <div className="overflow-x-auto scrollbar-hide">
          <div className="flex items-center gap-1 px-2 py-2 min-w-max">
            {allItems.map((item) => {
              const Icon = item.icon
              const active = isActive(item.path)
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex flex-col items-center py-2 px-3 rounded-lg transition-all duration-200 min-w-[70px] ${
                    active
                      ? 'text-primary bg-primary/10 scale-105 shadow-sm'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  <Icon className={`h-5 w-5 transition-transform duration-200 ${
                    active ? 'scale-110' : ''
                  }`} />
                  <span className={`text-xs mt-1 text-center leading-tight transition-all duration-200 ${
                    active ? 'font-medium' : ''
                  }`}>
                    {item.label}
                  </span>
                </Link>
              )
            })}
          </div>
        </div>
      </div>
      
      {/* Indicador de scroll (opcional) */}
      <div className="flex justify-center py-1">
        <div className="w-8 h-1 bg-muted rounded-full opacity-30"></div>
      </div>
    </div>
  )
}

export default BottomNavigation

