import React from 'react';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Heart, Scissors } from 'lucide-react';

const FichaAnamnese = ({ anamneseData, setAnamneseData }) => {
  const handleCheckboxChange = (field, value) => {
    setAnamneseData(prev => {
      const currentArray = prev[field] || [];
      const isChecked = currentArray.includes(value);
      
      return {
        ...prev,
        [field]: isChecked
          ? currentArray.filter(item => item !== value)
          : [...currentArray, value]
      };
    });
  };

  const handleTextareaChange = (field, value) => {
    setAnamneseData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Garantir que os dados da anamnese tenham a estrutura correta
  const dadosAnamnese = {
    historicoSaude: anamneseData?.historicoSaude || [],
    saudeObservacoes: anamneseData?.saudeObservacoes || '',
    historicoTatuagem: anamneseData?.historicoTatuagem || [],
    tatuagemObservacoes: anamneseData?.tatuagemObservacoes || '',
    expectativasCuidados: anamneseData?.expectativasCuidados || ''
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <Heart className="h-5 w-5 text-red-500" />
        <h3 className="text-lg font-semibold">Ficha de Anamnese</h3>
        <Badge variant="outline" className="text-xs">
          Obrigatório
        </Badge>
      </div>

      {/* Histórico de Saúde */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <AlertTriangle className="h-4 w-4 text-orange-500" />
            <span>Histórico de Saúde</span>
          </CardTitle>
          <CardDescription>
            Marque todas as condições de saúde que se aplicam ao cliente
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="diabetes"
                checked={dadosAnamnese.historicoSaude.includes('diabetes')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'diabetes')}
              />
              <Label htmlFor="diabetes" className="text-sm font-medium">
                Diabetes
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="hipertensao"
                checked={dadosAnamnese.historicoSaude.includes('hipertensao')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'hipertensao')}
              />
              <Label htmlFor="hipertensao" className="text-sm font-medium">
                Hipertensão
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="cardiaco"
                checked={dadosAnamnese.historicoSaude.includes('cardiaco')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'cardiaco')}
              />
              <Label htmlFor="cardiaco" className="text-sm font-medium">
                Problemas Cardíacos
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="alergias"
                checked={dadosAnamnese.historicoSaude.includes('alergias')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'alergias')}
              />
              <Label htmlFor="alergias" className="text-sm font-medium">
                Alergias (especificar abaixo)
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="hemofilia"
                checked={dadosAnamnese.historicoSaude.includes('hemofilia')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'hemofilia')}
              />
              <Label htmlFor="hemofilia" className="text-sm font-medium">
                Hemofilia
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="hepatite"
                checked={dadosAnamnese.historicoSaude.includes('hepatite')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'hepatite')}
              />
              <Label htmlFor="hepatite" className="text-sm font-medium">
                Hepatite
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="hiv"
                checked={dadosAnamnese.historicoSaude.includes('hiv')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'hiv')}
              />
              <Label htmlFor="hiv" className="text-sm font-medium">
                HIV
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="gravidez"
                checked={dadosAnamnese.historicoSaude.includes('gravidez')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'gravidez')}
              />
              <Label htmlFor="gravidez" className="text-sm font-medium">
                Gravidez/Amamentação
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="epilepsia"
                checked={dadosAnamnese.historicoSaude.includes('epilepsia')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'epilepsia')}
              />
              <Label htmlFor="epilepsia" className="text-sm font-medium">
                Epilepsia
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="medicamentos"
                checked={dadosAnamnese.historicoSaude.includes('medicamentos')}
                onCheckedChange={() => handleCheckboxChange('historicoSaude', 'medicamentos')}
              />
              <Label htmlFor="medicamentos" className="text-sm font-medium">
                Uso de medicamentos
              </Label>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <Label htmlFor="saudeObservacoes" className="text-sm font-medium">
              Observações sobre saúde, alergias ou medicamentos:
            </Label>
            <Textarea
              id="saudeObservacoes"
              placeholder="Especificar alergias, medicamentos em uso, outras condições de saúde ou observações importantes..."
              value={dadosAnamnese.saudeObservacoes}
              onChange={(e) => handleTextareaChange('saudeObservacoes', e.target.value)}
              rows={3}
              className="resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Histórico de Tatuagens/Piercings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Scissors className="h-4 w-4 text-blue-500" />
            <span>Histórico de Tatuagens/Piercings</span>
          </CardTitle>
          <CardDescription>
            Informações sobre experiências anteriores com tatuagens e piercings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="primeiraTatuagem"
                checked={dadosAnamnese.historicoTatuagem.includes('primeiraTatuagem')}
                onCheckedChange={() => handleCheckboxChange('historicoTatuagem', 'primeiraTatuagem')}
              />
              <Label htmlFor="primeiraTatuagem" className="text-sm font-medium">
                Primeira Tatuagem
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="tatuagensAnteriores"
                checked={dadosAnamnese.historicoTatuagem.includes('tatuagensAnteriores')}
                onCheckedChange={() => handleCheckboxChange('historicoTatuagem', 'tatuagensAnteriores')}
              />
              <Label htmlFor="tatuagensAnteriores" className="text-sm font-medium">
                Já possui tatuagens
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="piercingsAnteriores"
                checked={dadosAnamnese.historicoTatuagem.includes('piercingsAnteriores')}
                onCheckedChange={() => handleCheckboxChange('historicoTatuagem', 'piercingsAnteriores')}
              />
              <Label htmlFor="piercingsAnteriores" className="text-sm font-medium">
                Já possui piercings
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="cicatrizacaoRuim"
                checked={dadosAnamnese.historicoTatuagem.includes('cicatrizacaoRuim')}
                onCheckedChange={() => handleCheckboxChange('historicoTatuagem', 'cicatrizacaoRuim')}
              />
              <Label htmlFor="cicatrizacaoRuim" className="text-sm font-medium">
                Histórico de cicatrização ruim
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="queloides"
                checked={dadosAnamnese.historicoTatuagem.includes('queloides')}
                onCheckedChange={() => handleCheckboxChange('historicoTatuagem', 'queloides')}
              />
              <Label htmlFor="queloides" className="text-sm font-medium">
                Tendência a queloides
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="infeccaoAnterior"
                checked={dadosAnamnese.historicoTatuagem.includes('infeccaoAnterior')}
                onCheckedChange={() => handleCheckboxChange('historicoTatuagem', 'infeccaoAnterior')}
              />
              <Label htmlFor="infeccaoAnterior" className="text-sm font-medium">
                Infecção anterior
              </Label>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <Label htmlFor="tatuagemObservacoes" className="text-sm font-medium">
              Detalhes sobre tatuagens/piercings anteriores:
            </Label>
            <Textarea
              id="tatuagemObservacoes"
              placeholder="Quantas tatuagens possui, onde estão localizadas, como foi a cicatrização, problemas anteriores..."
              value={dadosAnamnese.tatuagemObservacoes}
              onChange={(e) => handleTextareaChange('tatuagemObservacoes', e.target.value)}
              rows={3}
              className="resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Expectativas e Cuidados */}
      <Card>
        <CardHeader>
          <CardTitle>Expectativas e Cuidados</CardTitle>
          <CardDescription>
            Informações sobre as expectativas do cliente e orientações sobre cuidados
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="expectativasCuidados" className="text-sm font-medium">
              Expectativas, dúvidas e orientações:
            </Label>
            <Textarea
              id="expectativasCuidados"
              placeholder="Expectativas do cliente sobre o resultado, dúvidas sobre o processo, orientações sobre cuidados pós-procedimento, tolerância à dor..."
              value={dadosAnamnese.expectativasCuidados}
              onChange={(e) => handleTextareaChange('expectativasCuidados', e.target.value)}
              rows={4}
              className="resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Resumo das informações selecionadas */}
      {(dadosAnamnese.historicoSaude.length > 0 || dadosAnamnese.historicoTatuagem.length > 0) && (
        <Card className="bg-muted/50">
          <CardHeader>
            <CardTitle className="text-sm">Resumo da Anamnese</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {dadosAnamnese.historicoSaude.length > 0 && (
                <div>
                  <span className="text-xs font-medium text-muted-foreground">Condições de Saúde:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {dadosAnamnese.historicoSaude.map((condicao) => (
                      <Badge key={condicao} variant="secondary" className="text-xs">
                        {condicao}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {dadosAnamnese.historicoTatuagem.length > 0 && (
                <div>
                  <span className="text-xs font-medium text-muted-foreground">Histórico de Tatuagem:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {dadosAnamnese.historicoTatuagem.map((historico) => (
                      <Badge key={historico} variant="outline" className="text-xs">
                        {historico}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default FichaAnamnese;


