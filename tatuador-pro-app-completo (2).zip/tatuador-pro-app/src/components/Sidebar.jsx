import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { 
  LayoutDashboard, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Calendar, 
  Store, 
  Image, 
  Package, 
  Calculator,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Settings,
  User,
  FileText,
  Info
} from 'lucide-react'
import logo from '../assets/logo.jpg'

const Sidebar = () => {
  const [isExpanded, setIsExpanded] = useState(true)
  const location = useLocation()

  const menuItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/ganhos', icon: TrendingUp, label: 'Ganhos' },
    { path: '/gastos', icon: TrendingDown, label: 'Gastos' },
    { path: '/clientes', icon: Users, label: 'Clientes' },
    { path: '/agenda', icon: Calendar, label: 'Agenda' },
    { path: '/loja', icon: Store, label: 'Loja' },
    { path: '/portfolio', icon: Image, label: 'Portfólio' },
    { path: '/estoque', icon: Package, label: 'Estoque' },
    { path: '/calculadora', icon: Calculator, label: 'Calculadora' },
    { path: '/relatorios', icon: BarChart3, label: 'Relatórios' },
    { path: '/sobre-nos', icon: Info, label: 'Sobre Nós' }
  ]

  const isActive = (path) => location.pathname === path

  return (
    <div className={`fixed left-0 top-0 h-full bg-sidebar border-r border-sidebar-border transition-all duration-300 z-50 ${
      isExpanded ? 'w-64' : 'w-16'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        {isExpanded && (
          <div className="flex items-center space-x-3">
            <img src={logo} alt="Logo" className="h-8 w-8" />
            <span className="font-bold text-sidebar-foreground">TATUADOR PRO</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-sidebar-foreground hover:bg-sidebar-accent"
        >
          {isExpanded ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                    isActive(item.path)
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <Icon className="h-5 w-5 flex-shrink-0" />
                  {isExpanded && <span className="font-medium">{item.label}</span>}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="space-y-2">

          
          <Link 
            to="/politica-de-privacidade" 
            className={`flex items-center w-full px-3 py-2 rounded-lg transition-colors text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground ${
              !isExpanded ? 'justify-center' : 'justify-start'
            }`}
          >
            <User className="h-5 w-5 flex-shrink-0" />
            {isExpanded && <span className="ml-3">Política de Privacidade</span>}
          </Link>

          <Link 
            to="/termos-de-uso" 
            className={`flex items-center w-full px-3 py-2 rounded-lg transition-colors text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground ${
              !isExpanded ? 'justify-center' : 'justify-start'
            }`}
          >
            <FileText className="h-5 w-5 flex-shrink-0" />
            {isExpanded && <span className="ml-3">Termos de Uso</span>}
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Sidebar

