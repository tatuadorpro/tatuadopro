import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Target,
  Calendar,
  Plus,
  Edit
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const Dashboard = () => {
  // Estado para controlar a meta mensal
  const [metaMensal, setMetaMensal] = useState(5000.00)
  const [novaMetaMensal, setNovaMetaMensal] = useState('')
  const [dialogAberto, setDialogAberto] = useState(false)

  // Dados mockados para demonstração
  const financialData = {
    totalGanhos: 15750.00,
    ganhosMes: 4250.00,
    gastosMes: 1800.00,
    lucroMes: 2450.00,
    aReceber: 3200.00,
    metaMensal: metaMensal
  }

  // Função para salvar a nova meta
  const salvarNovaMeta = () => {
    const valorNumerico = parseFloat(novaMetaMensal.replace(',', '.'))
    if (!isNaN(valorNumerico) && valorNumerico > 0) {
      setMetaMensal(valorNumerico)
      setDialogAberto(false)
      setNovaMetaMensal('')
    }
  }

  // Função para abrir o dialog de edição
  const abrirDialogEdicao = () => {
    setNovaMetaMensal(metaMensal.toString())
    setDialogAberto(true)
  }

  const ganhosPorTipo = [
    { name: 'Tatuagem', value: 8500, color: '#e50914' },
    { name: 'Curso', value: 3200, color: '#ff6b6b' },
    { name: 'Piercing', value: 2100, color: '#28a745' },
    { name: 'Produtos', value: 1950, color: '#ffc107' }
  ]

  const ultimasTransacoes = [
    { id: 1, tipo: 'ganho', descricao: 'Tatuagem - João Silva', valor: 450.00, data: '2024-01-20' },
    { id: 2, tipo: 'gasto', descricao: 'Tintas - Fornecedor ABC', valor: -120.00, data: '2024-01-19' },
    { id: 3, tipo: 'ganho', descricao: 'Curso Básico - Maria Santos', valor: 800.00, data: '2024-01-18' },
    { id: 4, tipo: 'gasto', descricao: 'Aluguel Estúdio', valor: -600.00, data: '2024-01-15' },
    { id: 5, tipo: 'ganho', descricao: 'Piercing - Ana Costa', valor: 180.00, data: '2024-01-14' }
  ]

  const progressoMeta = (financialData.ganhosMes / financialData.metaMensal) * 100

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Visão geral do seu estúdio</p>
        </div>

      </div>

      {/* Cards de Resumo Financeiro */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Ganhos</CardTitle>
            <TrendingUp className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {financialData.totalGanhos.toLocaleString('pt-BR')}
            </div>
            <p className="text-xs text-muted-foreground">Histórico geral</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ganhos do Mês</CardTitle>
            <DollarSign className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {financialData.ganhosMes.toLocaleString('pt-BR')}
            </div>
            <p className="text-xs text-muted-foreground">Janeiro 2024</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Gastos do Mês</CardTitle>
            <TrendingDown className="h-4 w-4 text-expense" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-expense">
              R$ {financialData.gastosMes.toLocaleString('pt-BR')}
            </div>
            <p className="text-xs text-muted-foreground">Janeiro 2024</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lucro do Mês</CardTitle>
            <TrendingUp className="h-4 w-4 text-gain" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gain">
              R$ {financialData.lucroMes.toLocaleString('pt-BR')}
            </div>
            <p className="text-xs text-muted-foreground">Ganhos - Gastos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">A Receber</CardTitle>
            <Calendar className="h-4 w-4 text-pending" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pending">
              R$ {financialData.aReceber.toLocaleString('pt-BR')}
            </div>
            <p className="text-xs text-muted-foreground">Valores pendentes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Meta Mensal</CardTitle>
            <div className="flex items-center space-x-2">
              <Target className="h-4 w-4 text-primary" />
              <Dialog open={dialogAberto} onOpenChange={setDialogAberto}>
                <DialogTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-6 w-6 p-0"
                    onClick={abrirDialogEdicao}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Editar Meta Mensal</DialogTitle>
                    <DialogDescription>
                      Defina sua nova meta mensal de ganhos. Digite o valor em reais.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="meta" className="text-right">
                        Meta (R$)
                      </Label>
                      <Input
                        id="meta"
                        type="number"
                        step="0.01"
                        min="0"
                        value={novaMetaMensal}
                        onChange={(e) => setNovaMetaMensal(e.target.value)}
                        className="col-span-3"
                        placeholder="Ex: 5000.00"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setDialogAberto(false)}
                    >
                      Cancelar
                    </Button>
                    <Button type="submit" onClick={salvarNovaMeta}>
                      Salvar Meta
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              R$ {financialData.metaMensal.toLocaleString('pt-BR')}
            </div>
            <div className="flex items-center space-x-2 mt-2">
              <div className="flex-1 bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(progressoMeta, 100)}%` }}
                />
              </div>
              <span className="text-xs text-muted-foreground">
                {progressoMeta.toFixed(0)}%
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico de Ganhos por Tipo */}
        <Card>
          <CardHeader>
            <CardTitle>Ganhos por Tipo</CardTitle>
            <CardDescription>Distribuição dos ganhos por categoria</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={ganhosPorTipo}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {ganhosPorTipo.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Resumo Geral */}
        <Card>
          <CardHeader>
            <CardTitle>Resumo Geral</CardTitle>
            <CardDescription>Visão consolidada das finanças</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Total de Ganhos:</span>
              <span className="text-sm font-bold text-gain">
                R$ {financialData.totalGanhos.toLocaleString('pt-BR')}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Total de Gastos:</span>
              <span className="text-sm font-bold text-expense">
                R$ {financialData.gastosMes.toLocaleString('pt-BR')}
              </span>
            </div>
            <div className="border-t pt-4">
              <div className="flex justify-between items-center">
                <span className="text-base font-medium">Lucro Total:</span>
                <span className="text-base font-bold text-gain">
                  R$ {(financialData.totalGanhos - financialData.gastosMes).toLocaleString('pt-BR')}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Últimas Transações */}
      <Card>
        <CardHeader>
          <CardTitle>Últimas Transações</CardTitle>
          <CardDescription>Movimentações recentes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {ultimasTransacoes.map((transacao) => (
              <div key={transacao.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  {transacao.tipo === 'ganho' ? (
                    <TrendingUp className="h-5 w-5 text-gain" />
                  ) : (
                    <TrendingDown className="h-5 w-5 text-expense" />
                  )}
                  <div>
                    <p className="font-medium">{transacao.descricao}</p>
                    <p className="text-sm text-muted-foreground">{transacao.data}</p>
                  </div>
                </div>
                <span className={`font-bold ${
                  transacao.tipo === 'ganho' ? 'text-gain' : 'text-expense'
                }`}>
                  {transacao.tipo === 'ganho' ? '+' : ''}R$ {Math.abs(transacao.valor).toLocaleString('pt-BR')}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard

