// Utilitário para gerenciar curtidas no localStorage

export const getCurtidas = () => {
  try {
    const curtidas = localStorage.getItem('curtidas_portfolio')
    return curtidas ? JSON.parse(curtidas) : []
  } catch (error) {
    console.error('Erro ao carregar curtidas:', error)
    return []
  }
}

export const setCurtidas = (curtidas) => {
  try {
    localStorage.setItem('curtidas_portfolio', JSON.stringify(curtidas))
  } catch (error) {
    console.error('Erro ao salvar curtidas:', error)
  }
}

export const adicionarCurtida = (trabalhoId) => {
  const curtidas = getCurtidas()
  if (!curtidas.includes(trabalhoId)) {
    curtidas.push(trabalhoId)
    setCurtidas(curtidas)
  }
  return curtidas
}

export const removerCurtida = (trabalhoId) => {
  const curtidas = getCurtidas()
  const novasCurtidas = curtidas.filter(id => id !== trabalhoId)
  setCurtidas(novasCurtidas)
  return novasCurtidas
}

export const toggleCurtida = (trabalhoId) => {
  const curtidas = getCurtidas()
  if (curtidas.includes(trabalhoId)) {
    return removerCurtida(trabalhoId)
  } else {
    return adicionarCurtida(trabalhoId)
  }
}

export const isCurtido = (trabalhoId) => {
  const curtidas = getCurtidas()
  return curtidas.includes(trabalhoId)
}

